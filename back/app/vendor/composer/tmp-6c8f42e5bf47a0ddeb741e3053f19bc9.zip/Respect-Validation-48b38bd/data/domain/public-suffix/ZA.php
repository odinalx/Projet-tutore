<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AC.ZA',
    'AGRIC.ZA',
    'ALT.ZA',
    'CO.ZA',
    'EDU.ZA',
    'GOV.ZA',
    'GRONDAR.ZA',
    'LAW.ZA',
    'MIL.ZA',
    'NET.ZA',
    'NGO.ZA',
    'NIC.ZA',
    'NIS.ZA',
    'NOM.ZA',
    'ORG.ZA',
    'SCHOOL.ZA',
    'TM.ZA',
    'WEB.ZA',
];
