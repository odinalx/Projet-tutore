<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'CO.AO',
    'ED.AO',
    'EDU.AO',
    'GOV.AO',
    'GV.AO',
    'IT.AO',
    'OG.AO',
    'ORG.AO',
    'PB.AO',
];
