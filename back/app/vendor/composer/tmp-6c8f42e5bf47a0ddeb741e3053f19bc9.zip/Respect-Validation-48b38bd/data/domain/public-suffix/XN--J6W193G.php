<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'XN--55QX5D.XN--J6W193G',
    'XN--GMQW5A.XN--J6W193G',
    'XN--MXTQ1M.XN--J6W193G',
    'XN--OD0ALG.XN--J6W193G',
    'XN--UC0ATV.XN--J6W193G',
    'XN--WCVS22D.XN--J6W193G',
];
