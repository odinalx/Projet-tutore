<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'COM.TN',
    'ENS.TN',
    'FIN.TN',
    'GOV.TN',
    'IND.TN',
    'INFO.TN',
    'INTL.TN',
    'MINCOM.TN',
    'NAT.TN',
    'NET.TN',
    'ORG.TN',
    'PERSO.TN',
    'TOURISM.TN',
];
