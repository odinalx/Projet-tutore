<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'COM.SD',
    'EDU.SD',
    'GOV.SD',
    'INFO.SD',
    'MED.SD',
    'NET.SD',
    'ORG.SD',
    'TV.SD',
];
