<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'ARTS.NF',
    'COM.NF',
    'FIRM.NF',
    'INFO.NF',
    'NET.NF',
    'OTHER.NF',
    'PER.NF',
    'REC.NF',
    'STORE.NF',
    'WEB.NF',
];
