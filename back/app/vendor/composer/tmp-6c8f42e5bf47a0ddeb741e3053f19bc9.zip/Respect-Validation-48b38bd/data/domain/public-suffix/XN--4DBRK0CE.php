<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'XN--4DBGDTY6C.XN--4DBRK0CE',
    'XN--5DBHL8D.XN--4DBRK0CE',
    'XN--8DBQ2A.XN--4DBRK0CE',
    'XN--HEBDA8B.XN--4DBRK0CE',
];
