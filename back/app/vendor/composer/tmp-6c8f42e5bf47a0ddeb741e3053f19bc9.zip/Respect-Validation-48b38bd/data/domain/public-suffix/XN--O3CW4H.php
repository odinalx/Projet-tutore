<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'XN--12C1FE0BR.XN--O3CW4H',
    'XN--12CFI8IXB8L.XN--O3CW4H',
    'XN--12CO0C3B4EVA.XN--O3CW4H',
    'XN--H3CUZK1DI.XN--O3CW4H',
    'XN--M3CH0J3A.XN--O3CW4H',
    'XN--O3CYX2A.XN--O3CW4H',
];
