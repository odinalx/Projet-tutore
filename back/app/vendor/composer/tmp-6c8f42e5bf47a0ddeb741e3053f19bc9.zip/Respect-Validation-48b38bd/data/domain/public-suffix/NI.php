<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AC.NI',
    'BIZ.NI',
    'CO.NI',
    'COM.NI',
    'EDU.NI',
    'GOB.NI',
    'IN.NI',
    'INFO.NI',
    'INT.NI',
    'MIL.NI',
    'NET.NI',
    'NOM.NI',
    'ORG.NI',
    'WEB.NI',
];
