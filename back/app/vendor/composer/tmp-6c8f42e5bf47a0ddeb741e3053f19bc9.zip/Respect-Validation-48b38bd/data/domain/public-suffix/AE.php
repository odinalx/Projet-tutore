<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AC.AE',
    'CO.AE',
    'GOV.AE',
    'MIL.AE',
    'NET.AE',
    'ORG.AE',
    'SCH.AE',
];
