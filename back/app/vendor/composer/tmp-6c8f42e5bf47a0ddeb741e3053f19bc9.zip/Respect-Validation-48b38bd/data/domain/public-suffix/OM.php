<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'CO.OM',
    'COM.OM',
    'EDU.OM',
    'GOV.OM',
    'MED.OM',
    'MUSEUM.OM',
    'NET.OM',
    'ORG.OM',
    'PRO.OM',
];
