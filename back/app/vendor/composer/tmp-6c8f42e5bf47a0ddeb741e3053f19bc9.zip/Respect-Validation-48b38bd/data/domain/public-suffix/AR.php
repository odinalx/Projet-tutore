<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'BET.AR',
    'COM.AR',
    'COOP.AR',
    'EDU.AR',
    'GOB.AR',
    'GOV.AR',
    'INT.AR',
    'MIL.AR',
    'MUSICA.AR',
    'MUTUAL.AR',
    'NET.AR',
    'ORG.AR',
    'SENASA.AR',
    'TUR.AR',
];
