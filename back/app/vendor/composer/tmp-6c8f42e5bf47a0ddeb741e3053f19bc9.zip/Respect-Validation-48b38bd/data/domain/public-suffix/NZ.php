<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AC.NZ',
    'CO.NZ',
    'CRI.NZ',
    'GEEK.NZ',
    'GEN.NZ',
    'GOVT.NZ',
    'HEALTH.NZ',
    'IWI.NZ',
    'KIWI.NZ',
    'MAORI.NZ',
    'MIL.NZ',
    'NET.NZ',
    'ORG.NZ',
    'PARLIAMENT.NZ',
    'SCHOOL.NZ',
    'XN--MORI-QSA.NZ',
];
