<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AFRICA.BJ',
    'AGRO.BJ',
    'ARCHITECTES.BJ',
    'ASSUR.BJ',
    'AVOCATS.BJ',
    'CO.BJ',
    'COM.BJ',
    'ECO.BJ',
    'ECONO.BJ',
    'EDU.BJ',
    'INFO.BJ',
    'LOISIRS.BJ',
    'MONEY.BJ',
    'NET.BJ',
    'ORG.BJ',
    'OTE.BJ',
    'RESTAURANT.BJ',
    'RESTO.BJ',
    'TOURISM.BJ',
    'UNIV.BJ',
];
