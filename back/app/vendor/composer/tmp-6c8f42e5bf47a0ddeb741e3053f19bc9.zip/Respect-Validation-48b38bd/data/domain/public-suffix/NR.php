<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'BIZ.NR',
    'COM.NR',
    'EDU.NR',
    'GOV.NR',
    'INFO.NR',
    'NET.NR',
    'ORG.NR',
];
