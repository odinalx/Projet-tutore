<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'BIZ.AZ',
    'CO.AZ',
    'COM.AZ',
    'EDU.AZ',
    'GOV.AZ',
    'INFO.AZ',
    'INT.AZ',
    'MIL.AZ',
    'NAME.AZ',
    'NET.AZ',
    'ORG.AZ',
    'PP.AZ',
    'PRO.AZ',
];
