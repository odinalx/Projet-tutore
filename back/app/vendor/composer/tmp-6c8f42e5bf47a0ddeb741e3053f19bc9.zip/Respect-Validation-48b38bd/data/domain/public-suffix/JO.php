<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AGRI.JO',
    'AI.JO',
    'COM.JO',
    'EDU.JO',
    'ENG.JO',
    'FM.JO',
    'GOV.JO',
    'MIL.JO',
    'NET.JO',
    'ORG.JO',
    'PER.JO',
    'PHD.JO',
    'SCH.JO',
    'TV.JO',
];
