<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'COM.IQ',
    'EDU.IQ',
    'GOV.IQ',
    'MIL.IQ',
    'NET.IQ',
    'ORG.IQ',
];
