<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AAA.PRO',
    'ACA.PRO',
    'ACCT.PRO',
    'AVOCAT.PRO',
    'BAR.PRO',
    'CPA.PRO',
    'ENG.PRO',
    'JUR.PRO',
    'LAW.PRO',
    'MED.PRO',
    'RECHT.PRO',
];
