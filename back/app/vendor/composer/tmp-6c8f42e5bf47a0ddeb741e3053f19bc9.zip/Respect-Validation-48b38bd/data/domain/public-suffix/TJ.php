<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AC.TJ',
    'BIZ.TJ',
    'CO.TJ',
    'COM.TJ',
    'EDU.TJ',
    'GO.TJ',
    'GOV.TJ',
    'INT.TJ',
    'MIL.TJ',
    'NAME.TJ',
    'NET.TJ',
    'NIC.TJ',
    'ORG.TJ',
    'TEST.TJ',
    'WEB.TJ',
];
