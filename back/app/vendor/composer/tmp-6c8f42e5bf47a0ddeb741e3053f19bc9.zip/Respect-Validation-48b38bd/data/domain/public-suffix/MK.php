<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'COM.MK',
    'EDU.MK',
    'GOV.MK',
    'INF.MK',
    'NAME.MK',
    'NET.MK',
    'ORG.MK',
];
