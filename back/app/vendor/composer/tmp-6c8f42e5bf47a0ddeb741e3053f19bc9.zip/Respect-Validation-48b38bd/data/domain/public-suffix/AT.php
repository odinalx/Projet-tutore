<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AC.AT',
    'CO.AT',
    'GV.AT',
    'OR.AT',
    'STH.AC.AT',
];
