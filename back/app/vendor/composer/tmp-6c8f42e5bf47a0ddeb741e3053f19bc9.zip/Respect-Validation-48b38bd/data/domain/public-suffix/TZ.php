<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AC.TZ',
    'CO.TZ',
    'GO.TZ',
    'HOTEL.TZ',
    'INFO.TZ',
    'ME.TZ',
    'MIL.TZ',
    'MOBI.TZ',
    'NE.TZ',
    'OR.TZ',
    'SC.TZ',
    'TV.TZ',
];
