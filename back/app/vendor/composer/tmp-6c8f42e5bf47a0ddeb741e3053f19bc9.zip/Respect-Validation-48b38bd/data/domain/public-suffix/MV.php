<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AERO.MV',
    'BIZ.MV',
    'COM.MV',
    'COOP.MV',
    'EDU.MV',
    'GOV.MV',
    'INFO.MV',
    'INT.MV',
    'MIL.MV',
    'MUSEUM.MV',
    'NAME.MV',
    'NET.MV',
    'ORG.MV',
    'PRO.MV',
];
