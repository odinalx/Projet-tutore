<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'BIZ.BB',
    'CO.BB',
    'COM.BB',
    'EDU.BB',
    'GOV.BB',
    'INFO.BB',
    'NET.BB',
    'ORG.BB',
    'STORE.BB',
    'TV.BB',
];
