<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'COM.LA',
    'EDU.LA',
    'GOV.LA',
    'INFO.LA',
    'INT.LA',
    'NET.LA',
    'ORG.LA',
    'PER.LA',
];
