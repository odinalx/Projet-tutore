<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AC.EG',
    'COM.EG',
    'EDU.EG',
    'EUN.EG',
    'GOV.EG',
    'INFO.EG',
    'ME.EG',
    'MIL.EG',
    'NAME.EG',
    'NET.EG',
    'ORG.EG',
    'SCI.EG',
    'SPORT.EG',
    'TV.EG',
];
