<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'ASS.KM',
    'ASSO.KM',
    'COM.KM',
    'COOP.KM',
    'EDU.KM',
    'GOUV.KM',
    'GOV.KM',
    'MEDECIN.KM',
    'MIL.KM',
    'NOM.KM',
    'NOTAIRES.KM',
    'ORG.KM',
    'PHARMACIENS.KM',
    'PRD.KM',
    'PRESSE.KM',
    'TM.KM',
    'VETERINAIRE.KM',
];
