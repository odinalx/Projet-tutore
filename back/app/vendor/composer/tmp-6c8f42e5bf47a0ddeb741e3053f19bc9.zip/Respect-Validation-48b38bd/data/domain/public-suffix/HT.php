<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'ADULT.HT',
    'ART.HT',
    'ASSO.HT',
    'COM.HT',
    'COOP.HT',
    'EDU.HT',
    'FIRM.HT',
    'GOUV.HT',
    'INFO.HT',
    'MED.HT',
    'NET.HT',
    'ORG.HT',
    'PERSO.HT',
    'POL.HT',
    'PRO.HT',
    'REL.HT',
    'SHOP.HT',
];
