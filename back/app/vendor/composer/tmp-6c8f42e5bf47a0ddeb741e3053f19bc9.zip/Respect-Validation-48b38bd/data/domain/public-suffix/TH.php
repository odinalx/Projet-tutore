<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AC.TH',
    'CO.TH',
    'GO.TH',
    'IN.TH',
    'MI.TH',
    'NET.TH',
    'OR.TH',
];
