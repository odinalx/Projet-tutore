<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'COM.EC',
    'EDU.EC',
    'FIN.EC',
    'GOB.EC',
    'GOV.EC',
    'INFO.EC',
    'K12.EC',
    'MED.EC',
    'MIL.EC',
    'NET.EC',
    'ORG.EC',
    'PRO.EC',
];
