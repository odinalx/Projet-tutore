<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'ART.SN',
    'COM.SN',
    'EDU.SN',
    'GOUV.SN',
    'ORG.SN',
    'PERSO.SN',
    'UNIV.SN',
];
