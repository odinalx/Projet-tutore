<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'COM.HK',
    'EDU.HK',
    'GOV.HK',
    'IDV.HK',
    'NET.HK',
    'ORG.HK',
    'XN--55QX5D.HK',
    'XN--CIQPN.HK',
    'XN--GMQ050I.HK',
    'XN--GMQW5A.HK',
    'XN--IO0A7I.HK',
    'XN--LCVR32D.HK',
    'XN--MK0AXI.HK',
    'XN--MXTQ1M.HK',
    'XN--OD0ALG.HK',
    'XN--OD0AQ3B.HK',
    'XN--TN0AG.HK',
    'XN--UC0ATV.HK',
    'XN--UC0AY4A.HK',
    'XN--WCVS22D.HK',
    'XN--ZF0AVX.HK',
];
