<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AC.MW',
    'BIZ.MW',
    'CO.MW',
    'COM.MW',
    'COOP.MW',
    'EDU.MW',
    'GOV.MW',
    'INT.MW',
    'NET.MW',
    'ORG.MW',
];
