<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'CLUB.TW',
    'COM.TW',
    'EBIZ.TW',
    'EDU.TW',
    'GAME.TW',
    'GOV.TW',
    'IDV.TW',
    'MIL.TW',
    'NET.TW',
    'ORG.TW',
];
