<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'BIZ.TT',
    'CO.TT',
    'COM.TT',
    'EDU.TT',
    'GOV.TT',
    'INFO.TT',
    'MIL.TT',
    'NAME.TT',
    'NET.TT',
    'ORG.TT',
    'PRO.TT',
];
