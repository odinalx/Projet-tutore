<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AC.CY',
    'BIZ.CY',
    'COM.CY',
    'EKLOGES.CY',
    'GOV.CY',
    'LTD.CY',
    'MIL.CY',
    'NET.CY',
    'ORG.CY',
    'PRESS.CY',
    'PRO.CY',
    'TM.CY',
];
