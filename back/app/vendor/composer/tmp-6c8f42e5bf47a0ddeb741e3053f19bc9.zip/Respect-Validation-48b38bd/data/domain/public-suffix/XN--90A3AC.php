<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'XN--80AU.XN--90A3AC',
    'XN--90AZH.XN--90A3AC',
    'XN--C1AVG.XN--90A3AC',
    'XN--D1AT.XN--90A3AC',
    'XN--O1AC.XN--90A3AC',
    'XN--O1ACH.XN--90A3AC',
];
