<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AC.LK',
    'ASSN.LK',
    'COM.LK',
    'EDU.LK',
    'GOV.LK',
    'GRP.LK',
    'HOTEL.LK',
    'INT.LK',
    'LTD.LK',
    'NET.LK',
    'NGO.LK',
    'ORG.LK',
    'SCH.LK',
    'SOC.LK',
    'WEB.LK',
];
