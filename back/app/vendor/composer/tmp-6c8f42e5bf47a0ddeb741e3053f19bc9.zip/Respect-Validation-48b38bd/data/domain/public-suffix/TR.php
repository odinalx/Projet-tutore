<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AV.TR',
    'BBS.TR',
    'BEL.TR',
    'BIZ.TR',
    'COM.TR',
    'DR.TR',
    'EDU.TR',
    'GEN.TR',
    'GOV.NC.TR',
    'GOV.TR',
    'INFO.TR',
    'K12.TR',
    'KEP.TR',
    'MIL.TR',
    'NAME.TR',
    'NC.TR',
    'NET.TR',
    'ORG.TR',
    'POL.TR',
    'TEL.TR',
    'TSK.TR',
    'TV.TR',
    'WEB.TR',
];
