<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AC.ME',
    'CO.ME',
    'EDU.ME',
    'GOV.ME',
    'ITS.ME',
    'NET.ME',
    'ORG.ME',
    'PRIV.ME',
];
