<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'AC.ID',
    'BIZ.ID',
    'CO.ID',
    'DESA.ID',
    'GO.ID',
    'MIL.ID',
    'MY.ID',
    'NET.ID',
    'OR.ID',
    'PONPES.ID',
    'SCH.ID',
    'WEB.ID',
];
