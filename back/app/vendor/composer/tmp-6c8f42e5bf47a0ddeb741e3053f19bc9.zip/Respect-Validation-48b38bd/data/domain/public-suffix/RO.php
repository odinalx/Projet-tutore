<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'ARTS.RO',
    'COM.RO',
    'FIRM.RO',
    'INFO.RO',
    'NOM.RO',
    'NT.RO',
    'ORG.RO',
    'REC.RO',
    'STORE.RO',
    'TM.RO',
    'WWW.RO',
];
