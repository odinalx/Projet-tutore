<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'COM.QA',
    'EDU.QA',
    'GOV.QA',
    'MIL.QA',
    'NAME.QA',
    'NET.QA',
    'ORG.QA',
    'SCH.QA',
];
