<?php declare(strict_types=1);
// Copyright (c) https://publicsuffix.org
// SPDX-License-Identifier: MPL-2.0-no-copyleft-exception
return [
    'ASSO.FR',
    'AVOUES.FR',
    'CCI.FR',
    'COM.FR',
    'GOUV.FR',
    'GRETA.FR',
    'HUISSIER-JUSTICE.FR',
    'NOM.FR',
    'PRD.FR',
    'TM.FR',
];
