<?php
return [
  "country" => "Zambia",
  "subdivisions" => [
    "01" => "Western",
    "02" => "Central",
    "03" => "Eastern",
    "04" => "Luapula",
    "05" => "Northern",
    "06" => "North-Western",
    "07" => "Southern",
    "08" => "Copperbelt",
    "09" => "Lusaka",
    "10" => "Muchinga"
  ]
];
