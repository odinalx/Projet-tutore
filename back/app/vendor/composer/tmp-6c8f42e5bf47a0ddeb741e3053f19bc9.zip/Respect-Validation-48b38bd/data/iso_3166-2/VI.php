<?php
return [
  "country" => "Virgin Islands, U.S.",
  "subdivisions" => [
  ]
];
