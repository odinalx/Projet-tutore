<?php
return [
  "country" => "Georgia",
  "subdivisions" => [
    "AB" => "Abkhazia",
    "AJ" => "Ajaria",
    "GU" => "Guria",
    "IM" => "Imereti",
    "KA" => "K'akheti",
    "KK" => "Kvemo Kartli",
    "MM" => "Mtskheta-Mtianeti",
    "RL" => "Rach'a-Lechkhumi-Kvemo Svaneti",
    "SJ" => "Samtskhe-Javakheti",
    "SK" => "Shida Kartli",
    "SZ" => "Samegrelo-Zemo Svaneti",
    "TB" => "Tbilisi"
  ]
];
