<?php
return [
  "country" => "Falkland Islands (Malvinas)",
  "subdivisions" => [
  ]
];
