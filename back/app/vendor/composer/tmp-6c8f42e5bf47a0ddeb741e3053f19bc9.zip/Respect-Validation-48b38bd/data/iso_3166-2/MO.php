<?php
return [
  "country" => "Macao",
  "subdivisions" => [
  ]
];
