<?php
return [
  "country" => "South Georgia and the South Sandwich Islands",
  "subdivisions" => [
  ]
];
