<?php
return [
  "country" => "Curaçao",
  "subdivisions" => [
  ]
];
