<?php
return [
  "country" => "Saint Lucia",
  "subdivisions" => [
    "01" => "Anse la Raye",
    "02" => "Castries",
    "03" => "Choiseul",
    "05" => "Dennery",
    "06" => "Gros Islet",
    "07" => "Laborie",
    "08" => "Micoud",
    "10" => "Soufrière",
    "11" => "Vieux Fort",
    "12" => "Canaries"
  ]
];
