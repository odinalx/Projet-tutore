<?php
return [
  "country" => "Monaco",
  "subdivisions" => [
    "CL" => "La Colle",
    "CO" => "La Condamine",
    "FO" => "Fontvieille",
    "GA" => "La Gare",
    "JE" => "Jardin Exotique",
    "LA" => "Larvotto",
    "MA" => "Malbousquet",
    "MC" => "Monte-Carlo",
    "MG" => "Moneghetti",
    "MO" => "Monaco-Ville",
    "MU" => "Moulins",
    "PH" => "Port-Hercule",
    "SD" => "Sainte-Dévote",
    "SO" => "La Source",
    "SP" => "Spélugues",
    "SR" => "Saint-Roman",
    "VR" => "Vallon de la Rousse"
  ]
];
