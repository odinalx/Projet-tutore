<?php
return [
  "country" => "Botswana",
  "subdivisions" => [
    "CE" => "Central",
    "CH" => "Chobe",
    "FR" => "Francistown",
    "GA" => "Gaborone",
    "GH" => "Ghanzi",
    "JW" => "Jwaneng",
    "KG" => "Kgalagadi",
    "KL" => "Kgatleng",
    "KW" => "Kweneng",
    "LO" => "Lobatse",
    "NE" => "North East",
    "NW" => "North West",
    "SE" => "South East",
    "SO" => "Southern",
    "SP" => "Selibe Phikwe",
    "ST" => "Sowa Town"
  ]
];
