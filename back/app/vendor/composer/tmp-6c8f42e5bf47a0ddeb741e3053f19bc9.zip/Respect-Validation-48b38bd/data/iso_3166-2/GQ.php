<?php
return [
  "country" => "Equatorial Guinea",
  "subdivisions" => [
    "AN" => "Annobon",
    "BN" => "Bioko Nord",
    "BS" => "Bioko Sud",
    "C" => "Région Continentale",
    "CS" => "Centro Sud",
    "DJ" => "Djibloho",
    "I" => "Région Insulaire",
    "KN" => "Kié-Ntem",
    "LI" => "Littoral",
    "WN" => "Wele-Nzas"
  ]
];
