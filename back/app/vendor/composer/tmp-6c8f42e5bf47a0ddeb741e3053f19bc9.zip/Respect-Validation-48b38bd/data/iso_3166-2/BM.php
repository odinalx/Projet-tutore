<?php
return [
  "country" => "Bermuda",
  "subdivisions" => [
  ]
];
