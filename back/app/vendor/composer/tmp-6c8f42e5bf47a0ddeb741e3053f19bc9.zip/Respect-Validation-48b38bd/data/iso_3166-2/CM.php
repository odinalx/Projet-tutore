<?php
return [
  "country" => "Cameroon",
  "subdivisions" => [
    "AD" => "Adamaoua",
    "CE" => "Centre",
    "EN" => "Far North",
    "ES" => "East",
    "LT" => "Littoral",
    "NO" => "North",
    "NW" => "North-West",
    "OU" => "West",
    "SU" => "South",
    "SW" => "South-West"
  ]
];
