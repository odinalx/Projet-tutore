<?php
return [
  "country" => "Uruguay",
  "subdivisions" => [
    "AR" => "Artigas",
    "CA" => "Canelones",
    "CL" => "Cerro Largo",
    "CO" => "Colonia",
    "DU" => "Durazno",
    "FD" => "Florida",
    "FS" => "Flores",
    "LA" => "Lavalleja",
    "MA" => "Maldonado",
    "MO" => "Montevideo",
    "PA" => "Paysandú",
    "RN" => "Río Negro",
    "RO" => "Rocha",
    "RV" => "Rivera",
    "SA" => "Salto",
    "SJ" => "San José",
    "SO" => "Soriano",
    "TA" => "Tacuarembó",
    "TT" => "Treinta y Tres"
  ]
];
