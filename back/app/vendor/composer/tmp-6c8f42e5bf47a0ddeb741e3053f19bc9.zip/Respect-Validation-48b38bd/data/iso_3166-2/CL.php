<?php
return [
  "country" => "Chile",
  "subdivisions" => [
    "AI" => "Aisén del General Carlos Ibañez del Campo",
    "AN" => "Antofagasta",
    "AP" => "Arica y Parinacota",
    "AR" => "La Araucanía",
    "AT" => "Atacama",
    "BI" => "Biobío",
    "CO" => "Coquimbo",
    "LI" => "Libertador General Bernardo O'Higgins",
    "LL" => "Los Lagos",
    "LR" => "Los Ríos",
    "MA" => "Magallanes",
    "ML" => "Maule",
    "NB" => "Ñuble",
    "RM" => "Región Metropolitana de Santiago",
    "TA" => "Tarapacá",
    "VS" => "Valparaíso"
  ]
];
