<?php
return [
  "country" => "Lao People's Democratic Republic",
  "subdivisions" => [
    "AT" => "Attapu",
    "BK" => "Bokèo",
    "BL" => "Bolikhamxai",
    "CH" => "Champasak",
    "HO" => "Houaphan",
    "KH" => "Khammouan",
    "LM" => "Louang Namtha",
    "LP" => "Louangphabang",
    "OU" => "Oudômxai",
    "PH" => "Phôngsali",
    "SL" => "Salavan",
    "SV" => "Savannakhét",
    "VI" => "Viangchan",
    "VT" => "Viangchan",
    "XA" => "Xaignabouli",
    "XE" => "Xékong",
    "XI" => "Xiangkhouang",
    "XS" => "Xaisômboun"
  ]
];
