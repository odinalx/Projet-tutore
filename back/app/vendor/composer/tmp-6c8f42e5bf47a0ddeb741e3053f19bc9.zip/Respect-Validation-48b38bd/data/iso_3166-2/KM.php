<?php
return [
  "country" => "Comoros",
  "subdivisions" => [
    "A" => "Anjouan",
    "G" => "Grande Comore",
    "M" => "Mohéli"
  ]
];
