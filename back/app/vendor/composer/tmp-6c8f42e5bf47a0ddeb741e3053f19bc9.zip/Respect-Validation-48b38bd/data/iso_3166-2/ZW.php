<?php
return [
  "country" => "Zimbabwe",
  "subdivisions" => [
    "BU" => "Bulawayo",
    "HA" => "Harare",
    "MA" => "Manicaland",
    "MC" => "Mashonaland Central",
    "ME" => "Mashonaland East",
    "MI" => "Midlands",
    "MN" => "Matabeleland North",
    "MS" => "Matabeleland South",
    "MV" => "Masvingo",
    "MW" => "Mashonaland West"
  ]
];
