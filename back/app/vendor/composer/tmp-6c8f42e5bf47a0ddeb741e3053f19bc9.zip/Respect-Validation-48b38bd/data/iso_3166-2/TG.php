<?php
return [
  "country" => "Togo",
  "subdivisions" => [
    "C" => "Centrale",
    "K" => "Kara",
    "M" => "Maritime (Région)",
    "P" => "Plateaux",
    "S" => "Savanes"
  ]
];
