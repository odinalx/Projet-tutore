<?php
return [
  "country" => "Nepal",
  "subdivisions" => [
    "P1" => "Koshi",
    "P2" => "Madhesh",
    "P3" => "Bagmati",
    "P4" => "Gandaki",
    "P5" => "Lumbini",
    "P6" => "Karnali",
    "P7" => "Sudurpashchim"
  ]
];
