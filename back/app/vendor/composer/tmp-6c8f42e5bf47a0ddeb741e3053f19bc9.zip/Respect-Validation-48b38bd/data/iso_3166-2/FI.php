<?php
return [
  "country" => "Finland",
  "subdivisions" => [
    "01" => "Landskapet Åland",
    "02" => "Etelä-Karjala",
    "03" => "Etelä-Pohjanmaa",
    "04" => "Etelä-Savo",
    "05" => "Kainuu",
    "06" => "Kanta-Häme",
    "07" => "Keski-Pohjanmaa",
    "08" => "Keski-Suomi",
    "09" => "Kymenlaakso",
    "10" => "Lappi",
    "11" => "Pirkanmaa",
    "12" => "Pohjanmaa",
    "13" => "Pohjois-Karjala",
    "14" => "Pohjois-Pohjanmaa",
    "15" => "Pohjois-Savo",
    "16" => "Päijät-Häme",
    "17" => "Satakunta",
    "18" => "Uusimaa",
    "19" => "Varsinais-Suomi"
  ]
];
