<?php
return [
  "country" => "Chad",
  "subdivisions" => [
    "BA" => "Batha",
    "BG" => "Bahr el Ghazal",
    "BO" => "Borkou",
    "CB" => "Chari-Baguirmi",
    "EE" => "Ennedi-Est",
    "EO" => "Ennedi-Ouest",
    "GR" => "Guéra",
    "HL" => "Hadjer Lamis",
    "KA" => "Kanem",
    "LC" => "Lac",
    "LO" => "Logone-Occidental",
    "LR" => "Logone-Oriental",
    "MA" => "Mandoul",
    "MC" => "Moyen-Chari",
    "ME" => "Mayo-Kebbi-Est",
    "MO" => "Mayo-Kebbi-Ouest",
    "ND" => "Ville de Ndjamena",
    "OD" => "Ouaddaï",
    "SA" => "Salamat",
    "SI" => "Sila",
    "TA" => "Tandjilé",
    "TI" => "Tibesti",
    "WF" => "Wadi Fira"
  ]
];
