<?php
return [
  "country" => "Barbados",
  "subdivisions" => [
    "01" => "Christ Church",
    "02" => "Saint Andrew",
    "03" => "Saint George",
    "04" => "Saint James",
    "05" => "Saint John",
    "06" => "Saint Joseph",
    "07" => "Saint Lucy",
    "08" => "Saint Michael",
    "09" => "Saint Peter",
    "10" => "Saint Philip",
    "11" => "Saint Thomas"
  ]
];
