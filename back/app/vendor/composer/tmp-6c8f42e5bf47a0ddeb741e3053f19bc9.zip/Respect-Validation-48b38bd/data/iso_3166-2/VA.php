<?php
return [
  "country" => "Holy See (Vatican City State)",
  "subdivisions" => [
  ]
];
