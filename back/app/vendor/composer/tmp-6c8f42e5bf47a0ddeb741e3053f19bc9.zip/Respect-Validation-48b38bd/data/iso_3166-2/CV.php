<?php
return [
  "country" => "Cabo Verde",
  "subdivisions" => [
    "B" => "Ilhas de Barlavento",
    "BR" => "Brava",
    "BV" => "Boa Vista",
    "CA" => "Santa Catarina",
    "CF" => "Santa Catarina do Fogo",
    "CR" => "Santa Cruz",
    "MA" => "Maio",
    "MO" => "Mosteiros",
    "PA" => "Paul",
    "PN" => "Porto Novo",
    "PR" => "Praia",
    "RB" => "Ribeira Brava",
    "RG" => "Ribeira Grande",
    "RS" => "Ribeira Grande de Santiago",
    "S" => "Ilhas de Sotavento",
    "SD" => "São Domingos",
    "SF" => "São Filipe",
    "SL" => "Sal",
    "SM" => "São Miguel",
    "SO" => "São Lourenço dos Órgãos",
    "SS" => "São Salvador do Mundo",
    "SV" => "São Vicente",
    "TA" => "Tarrafal",
    "TS" => "Tarrafal de São Nicolau"
  ]
];
