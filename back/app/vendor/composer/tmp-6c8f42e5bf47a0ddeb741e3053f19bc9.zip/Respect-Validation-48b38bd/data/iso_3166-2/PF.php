<?php
return [
  "country" => "French Polynesia",
  "subdivisions" => [
  ]
];
