<?php
return [
  "country" => "United States Minor Outlying Islands",
  "subdivisions" => [
    "67" => "Johnston Atoll",
    "71" => "Midway Islands",
    "76" => "Navassa Island",
    "79" => "Wake Island",
    "81" => "Baker Island",
    "84" => "Howland Island",
    "86" => "Jarvis Island",
    "89" => "Kingman Reef",
    "95" => "Palmyra Atoll"
  ]
];
