<?php
return [
  "country" => "Panama",
  "subdivisions" => [
    "1" => "Bocas del Toro",
    "10" => "Panamá Oeste",
    "2" => "Coclé",
    "3" => "Colón",
    "4" => "Chiriquí",
    "5" => "Darién",
    "6" => "Herrera",
    "7" => "Los Santos",
    "8" => "Panamá",
    "9" => "Veraguas",
    "EM" => "Emberá",
    "KY" => "Guna Yala",
    "NB" => "Ngäbe-Buglé",
    "NT" => "Naso Tjër Di"
  ]
];
