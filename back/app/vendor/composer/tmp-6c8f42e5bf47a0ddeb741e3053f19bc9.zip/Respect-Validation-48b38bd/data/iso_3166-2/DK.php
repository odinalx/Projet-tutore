<?php
return [
  "country" => "Denmark",
  "subdivisions" => [
    "81" => "Nordjylland",
    "82" => "Midtjylland",
    "83" => "Syddanmark",
    "84" => "Hovedstaden",
    "85" => "Sjælland"
  ]
];
