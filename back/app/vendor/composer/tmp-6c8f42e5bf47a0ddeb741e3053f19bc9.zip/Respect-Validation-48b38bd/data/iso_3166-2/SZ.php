<?php
return [
  "country" => "Eswatini",
  "subdivisions" => [
    "HH" => "Hhohho",
    "LU" => "Lubombo",
    "MA" => "Manzini",
    "SH" => "Shiselweni"
  ]
];
