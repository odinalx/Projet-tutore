<?php
return [
  "country" => "Lebanon",
  "subdivisions" => [
    "AK" => "Aakkâr",
    "AS" => "Ash Shimāl",
    "BA" => "Bayrūt",
    "BH" => "Baalbek-Hermel",
    "BI" => "Al Biqā‘",
    "JA" => "Al Janūb",
    "JL" => "Jabal Lubnān",
    "NA" => "An Nabaţīyah"
  ]
];
