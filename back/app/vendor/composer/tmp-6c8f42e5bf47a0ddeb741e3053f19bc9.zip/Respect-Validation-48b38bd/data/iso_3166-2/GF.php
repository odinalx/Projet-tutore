<?php
return [
  "country" => "French Guiana",
  "subdivisions" => [
  ]
];
