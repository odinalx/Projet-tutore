<?php
return [
  "country" => "Turkmenistan",
  "subdivisions" => [
    "A" => "Ahal",
    "B" => "Balkan",
    "D" => "Daşoguz",
    "L" => "Lebap",
    "M" => "Mary",
    "S" => "Aşgabat"
  ]
];
