<?php
return [
  "country" => "Iraq",
  "subdivisions" => [
    "AN" => "Al Anbār",
    "AR" => "Arbīl",
    "BA" => "Al Başrah",
    "BB" => "Bābil",
    "BG" => "Baghdād",
    "DA" => "Dahūk",
    "DI" => "Diyālá",
    "DQ" => "Dhī Qār",
    "KA" => "Karbalā’",
    "KI" => "Kirkūk",
    "KR" => "Herêm-î Kurdistan",
    "MA" => "Maysān",
    "MU" => "Al Muthanná",
    "NA" => "An Najaf",
    "NI" => "Nīnawá",
    "QA" => "Al Qādisīyah",
    "SD" => "Şalāḩ ad Dīn",
    "SU" => "As Sulaymānīyah",
    "WA" => "Wāsiţ"
  ]
];
