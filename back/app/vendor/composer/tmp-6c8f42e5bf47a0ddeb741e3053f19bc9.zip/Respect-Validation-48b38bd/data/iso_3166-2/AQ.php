<?php
return [
  "country" => "Antarctica",
  "subdivisions" => [
  ]
];
