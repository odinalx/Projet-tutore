<?php
return [
  "country" => "Argentina",
  "subdivisions" => [
    "A" => "Salta",
    "B" => "Buenos Aires",
    "C" => "Ciudad Autónoma de Buenos Aires",
    "D" => "San Luis",
    "E" => "Entre Ríos",
    "F" => "La Rioja",
    "G" => "Santiago del Estero",
    "H" => "Chaco",
    "J" => "San Juan",
    "K" => "Catamarca",
    "L" => "La Pampa",
    "M" => "Mendoza",
    "N" => "Misiones",
    "P" => "Formosa",
    "Q" => "Neuquén",
    "R" => "Río Negro",
    "S" => "Santa Fe",
    "T" => "Tucumán",
    "U" => "Chubut",
    "V" => "Tierra del Fuego",
    "W" => "Corrientes",
    "X" => "Córdoba",
    "Y" => "Jujuy",
    "Z" => "Santa Cruz"
  ]
];
