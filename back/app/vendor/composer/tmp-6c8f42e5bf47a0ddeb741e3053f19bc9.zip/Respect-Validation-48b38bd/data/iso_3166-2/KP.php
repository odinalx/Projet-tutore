<?php
return [
  "country" => "Korea, Democratic People's Republic of",
  "subdivisions" => [
    "01" => "P'yǒngyang",
    "02" => "P'yǒngan-namdo",
    "03" => "P'yǒngan-bukto",
    "04" => "Chagang-do",
    "05" => "Hwanghae-namdo",
    "06" => "Hwanghae-bukto",
    "07" => "Kangweonto",
    "08" => "Hamgyǒng-namdo",
    "09" => "Hamgyǒng-bukto",
    "10" => "Ryanggang-do",
    "13" => "Raseon",
    "14" => "Nampho",
    "15" => "Kaeseong"
  ]
];
