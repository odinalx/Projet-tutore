<?php
return [
  "country" => "Ukraine",
  "subdivisions" => [
    "05" => "Vinnytska oblast",
    "07" => "Volynska oblast",
    "09" => "Luhanska oblast",
    "12" => "Dnipropetrovska oblast",
    "14" => "Donetska oblast",
    "18" => "Zhytomyrska oblast",
    "21" => "Zakarpatska oblast",
    "23" => "Zaporizka oblast",
    "26" => "Ivano-Frankivska oblast",
    "30" => "Kyiv",
    "32" => "Kyivska oblast",
    "35" => "Kirovohradska oblast",
    "40" => "Sevastopol",
    "43" => "Avtonomna Respublika Krym",
    "46" => "Lvivska oblast",
    "48" => "Mykolaivska oblast",
    "51" => "Odeska oblast",
    "53" => "Poltavska oblast",
    "56" => "Rivnenska oblast",
    "59" => "Sumska oblast",
    "61" => "Ternopilska oblast",
    "63" => "Kharkivska oblast",
    "65" => "Khersonska oblast",
    "68" => "Khmelnytska oblast",
    "71" => "Cherkaska oblast",
    "74" => "Chernihivska oblast",
    "77" => "Chernivetska oblast"
  ]
];
