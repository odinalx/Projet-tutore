<?php
return [
  "country" => "Tunisia",
  "subdivisions" => [
    "11" => "Tunis",
    "12" => "L'Ariana",
    "13" => "Ben Arous",
    "14" => "La Manouba",
    "21" => "Nabeul",
    "22" => "Zaghouan",
    "23" => "Bizerte",
    "31" => "Béja",
    "32" => "Jendouba",
    "33" => "Le Kef",
    "34" => "Siliana",
    "41" => "Kairouan",
    "42" => "Kasserine",
    "43" => "Sidi Bouzid",
    "51" => "Sousse",
    "52" => "Monastir",
    "53" => "Mahdia",
    "61" => "Sfax",
    "71" => "Gafsa",
    "72" => "Tozeur",
    "73" => "Kébili",
    "81" => "Gabès",
    "82" => "Médenine",
    "83" => "Tataouine"
  ]
];
