<?php
return [
  "country" => "Kyrgyzstan",
  "subdivisions" => [
    "B" => "Batken",
    "C" => "Chuyskaya oblast'",
    "GB" => "Bishkek Shaary",
    "GO" => "Gorod Osh",
    "J" => "Dzhalal-Abadskaya oblast'",
    "N" => "Naryn",
    "O" => "Osh",
    "T" => "Talas",
    "Y" => "Issyk-Kul'skaja oblast'"
  ]
];
