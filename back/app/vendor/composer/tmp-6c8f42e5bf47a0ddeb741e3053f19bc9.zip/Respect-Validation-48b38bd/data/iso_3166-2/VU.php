<?php
return [
  "country" => "Vanuatu",
  "subdivisions" => [
    "MAP" => "Malampa",
    "PAM" => "Pénama",
    "SAM" => "Sanma",
    "SEE" => "Shéfa",
    "TAE" => "Taféa",
    "TOB" => "Torba"
  ]
];
