<?php
return [
  "country" => "Palestine, State of",
  "subdivisions" => [
    "BTH" => "Bethlehem",
    "DEB" => "Deir El Balah",
    "GZA" => "Gaza",
    "HBN" => "Hebron",
    "JEM" => "Jerusalem",
    "JEN" => "Jenin",
    "JRH" => "Jericho and Al Aghwar",
    "KYS" => "Khan Yunis",
    "NBS" => "Nablus",
    "NGZ" => "North Gaza",
    "QQA" => "Qalqilya",
    "RBH" => "Ramallah",
    "RFH" => "Rafah",
    "SLT" => "Salfit",
    "TBS" => "Tubas",
    "TKM" => "Tulkarm"
  ]
];
