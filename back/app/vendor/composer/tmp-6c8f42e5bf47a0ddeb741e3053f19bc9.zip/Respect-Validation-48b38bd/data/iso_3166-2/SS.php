<?php
return [
  "country" => "South Sudan",
  "subdivisions" => [
    "BN" => "Northern Bahr el Ghazal",
    "BW" => "Western Bahr el Ghazal",
    "EC" => "Central Equatoria",
    "EE" => "Eastern Equatoria",
    "EW" => "Western Equatoria",
    "JG" => "Jonglei",
    "LK" => "Lakes",
    "NU" => "Upper Nile",
    "UY" => "Unity",
    "WR" => "Warrap"
  ]
];
