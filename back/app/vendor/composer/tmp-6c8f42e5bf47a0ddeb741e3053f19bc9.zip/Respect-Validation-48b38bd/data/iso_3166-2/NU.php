<?php
return [
  "country" => "Niue",
  "subdivisions" => [
  ]
];
