<?php
return [
  "country" => "Sao Tome and Principe",
  "subdivisions" => [
    "01" => "Água Grande",
    "02" => "Cantagalo",
    "03" => "Caué",
    "04" => "Lembá",
    "05" => "Lobata",
    "06" => "Mé-Zóchi",
    "P" => "Príncipe"
  ]
];
