<?php
return [
  "country" => "Guadeloupe",
  "subdivisions" => [
  ]
];
