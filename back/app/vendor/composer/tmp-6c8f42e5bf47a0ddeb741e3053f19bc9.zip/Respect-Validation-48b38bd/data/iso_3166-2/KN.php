<?php
return [
  "country" => "Saint Kitts and Nevis",
  "subdivisions" => [
    "01" => "Christ Church Nichola Town",
    "02" => "Saint Anne Sandy Point",
    "03" => "Saint George Basseterre",
    "04" => "Saint George Gingerland",
    "05" => "Saint James Windward",
    "06" => "Saint John Capisterre",
    "07" => "Saint John Figtree",
    "08" => "Saint Mary Cayon",
    "09" => "Saint Paul Capisterre",
    "10" => "Saint Paul Charlestown",
    "11" => "Saint Peter Basseterre",
    "12" => "Saint Thomas Lowland",
    "13" => "Saint Thomas Middle Island",
    "15" => "Trinity Palmetto Point",
    "K" => "Saint Kitts",
    "N" => "Nevis"
  ]
];
