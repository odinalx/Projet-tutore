<?php
return [
  "country" => "Congo",
  "subdivisions" => [
    "11" => "Bouenza",
    "12" => "Pool",
    "13" => "Sangha",
    "14" => "Plateaux",
    "15" => "Cuvette-Ouest",
    "16" => "Pointe-Noire",
    "2" => "Lékoumou",
    "5" => "Kouilou",
    "7" => "Likouala",
    "8" => "Cuvette",
    "9" => "Niari",
    "BZV" => "Brazzaville"
  ]
];
