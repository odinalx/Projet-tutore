<?php
return [
  "country" => "Marshall Islands",
  "subdivisions" => [
    "ALK" => "Ailuk",
    "ALL" => "Ailinglaplap",
    "ARN" => "Arno",
    "AUR" => "Aur",
    "EBO" => "Ebon",
    "ENI" => "Enewetak & Ujelang",
    "JAB" => "Jabat",
    "JAL" => "Jaluit",
    "KIL" => "Bikini & Kili",
    "KWA" => "Kwajalein",
    "L" => "Ralik chain",
    "LAE" => "Lae",
    "LIB" => "Lib",
    "LIK" => "Likiep",
    "MAJ" => "Majuro",
    "MAL" => "Maloelap",
    "MEJ" => "Mejit",
    "MIL" => "Mili",
    "NMK" => "Namdrik",
    "NMU" => "Namu",
    "RON" => "Rongelap",
    "T" => "Ratak chain",
    "UJA" => "Ujae",
    "UTI" => "Utrik",
    "WTH" => "Wotho",
    "WTJ" => "Wotje"
  ]
];
