<?php
return [
  "country" => "Pakistan",
  "subdivisions" => [
    "BA" => "Balochistan",
    "GB" => "Gilgit-Baltistan",
    "IS" => "Islamabad",
    "JK" => "Azad Jammu and Kashmir",
    "KP" => "Khyber Pakhtunkhwa",
    "PB" => "Punjab",
    "SD" => "Sindh"
  ]
];
