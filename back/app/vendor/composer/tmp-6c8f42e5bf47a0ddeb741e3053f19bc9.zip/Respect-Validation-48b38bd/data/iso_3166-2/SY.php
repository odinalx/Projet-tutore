<?php
return [
  "country" => "Syrian Arab Republic",
  "subdivisions" => [
    "DI" => "Dimashq",
    "DR" => "Dar'ā",
    "DY" => "Dayr az Zawr",
    "HA" => "Al Ḩasakah",
    "HI" => "Ḩimş",
    "HL" => "Ḩalab",
    "HM" => "Ḩamāh",
    "ID" => "Idlib",
    "LA" => "Al Lādhiqīyah",
    "QU" => "Al Qunayţirah",
    "RA" => "Ar Raqqah",
    "RD" => "Rīf Dimashq",
    "SU" => "As Suwaydā'",
    "TA" => "Ţarţūs"
  ]
];
