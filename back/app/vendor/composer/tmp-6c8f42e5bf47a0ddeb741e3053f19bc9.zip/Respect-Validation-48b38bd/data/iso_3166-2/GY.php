<?php
return [
  "country" => "Guyana",
  "subdivisions" => [
    "BA" => "Barima-Waini",
    "CU" => "Cuyuni-Mazaruni",
    "DE" => "Demerara-Mahaica",
    "EB" => "East Berbice-Corentyne",
    "ES" => "Essequibo Islands-West Demerara",
    "MA" => "Mahaica-Berbice",
    "PM" => "Pomeroon-Supenaam",
    "PT" => "Potaro-Siparuni",
    "UD" => "Upper Demerara-Berbice",
    "UT" => "Upper Takutu-Upper Essequibo"
  ]
];
