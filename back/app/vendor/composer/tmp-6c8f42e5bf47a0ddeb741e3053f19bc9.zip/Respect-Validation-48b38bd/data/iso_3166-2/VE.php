<?php
return [
  "country" => "Venezuela, Bolivarian Republic of",
  "subdivisions" => [
    "A" => "Distrito Capital",
    "B" => "Anzoátegui",
    "C" => "Apure",
    "D" => "Aragua",
    "E" => "Barinas",
    "F" => "Bolívar",
    "G" => "Carabobo",
    "H" => "Cojedes",
    "I" => "Falcón",
    "J" => "Guárico",
    "K" => "Lara",
    "L" => "Mérida",
    "M" => "Miranda",
    "N" => "Monagas",
    "O" => "Nueva Esparta",
    "P" => "Portuguesa",
    "R" => "Sucre",
    "S" => "Táchira",
    "T" => "Trujillo",
    "U" => "Yaracuy",
    "V" => "Zulia",
    "W" => "Dependencias Federales",
    "X" => "La Guaira",
    "Y" => "Delta Amacuro",
    "Z" => "Amazonas"
  ]
];
