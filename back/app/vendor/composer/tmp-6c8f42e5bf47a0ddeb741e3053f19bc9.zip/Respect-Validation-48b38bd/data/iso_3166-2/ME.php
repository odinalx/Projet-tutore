<?php
return [
  "country" => "Montenegro",
  "subdivisions" => [
    "01" => "Andrijevica",
    "02" => "Bar",
    "03" => "Berane",
    "04" => "Bijelo Polje",
    "05" => "Budva",
    "06" => "Cetinje",
    "07" => "Danilovgrad",
    "08" => "Herceg-Novi",
    "09" => "Kolašin",
    "10" => "Kotor",
    "11" => "Mojkovac",
    "12" => "Nikšić",
    "13" => "Plav",
    "14" => "Pljevlja",
    "15" => "Plužine",
    "16" => "Podgorica",
    "17" => "Rožaje",
    "18" => "Šavnik",
    "19" => "Tivat",
    "20" => "Ulcinj",
    "21" => "Žabljak",
    "22" => "Gusinje",
    "23" => "Petnjica",
    "24" => "Tuzi",
    "25" => "Zeta"
  ]
];
