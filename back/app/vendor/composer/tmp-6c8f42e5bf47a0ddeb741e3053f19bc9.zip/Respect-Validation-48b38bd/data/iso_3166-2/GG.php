<?php
return [
  "country" => "Guernsey",
  "subdivisions" => [
  ]
];
