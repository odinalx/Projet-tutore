<?php
return [
  "country" => "Grenada",
  "subdivisions" => [
    "01" => "Saint Andrew",
    "02" => "Saint David",
    "03" => "Saint George",
    "04" => "Saint John",
    "05" => "Saint Mark",
    "06" => "Saint Patrick",
    "10" => "Southern Grenadine Islands"
  ]
];
