<?php
return [
  "country" => "Guam",
  "subdivisions" => [
  ]
];
