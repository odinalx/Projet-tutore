<?php
return [
  "country" => "Mali",
  "subdivisions" => [
    "1" => "Kayes",
    "10" => "Taoudénit",
    "2" => "Koulikoro",
    "3" => "Sikasso",
    "4" => "Ségou",
    "5" => "Mopti",
    "6" => "Tombouctou",
    "7" => "Gao",
    "8" => "Kidal",
    "9" => "Ménaka",
    "BKO" => "Bamako"
  ]
];
