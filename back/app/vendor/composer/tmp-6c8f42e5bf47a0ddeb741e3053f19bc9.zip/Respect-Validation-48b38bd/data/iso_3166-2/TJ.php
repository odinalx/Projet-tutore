<?php
return [
  "country" => "Tajikistan",
  "subdivisions" => [
    "DU" => "Dushanbe",
    "GB" => "Kŭhistoni Badakhshon",
    "KT" => "Khatlon",
    "RA" => "nohiyahoi tobei jumhurí",
    "SU" => "Sughd"
  ]
];
