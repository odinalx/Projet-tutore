<?php
return [
  "country" => "Seychelles",
  "subdivisions" => [
    "01" => "Anse aux Pins",
    "02" => "Anse Boileau",
    "03" => "Anse Etoile",
    "04" => "Au Cap",
    "05" => "Anse Royale",
    "06" => "Baie Lazare",
    "07" => "Baie Sainte Anne",
    "08" => "Beau Vallon",
    "09" => "Bel Air",
    "10" => "Bel Ombre",
    "11" => "Cascade",
    "12" => "Glacis",
    "13" => "Grand Anse Mahe",
    "14" => "Grand Anse Praslin",
    "15" => "La Digue",
    "16" => "English River",
    "17" => "Mont Buxton",
    "18" => "Mont Fleuri",
    "19" => "Plaisance",
    "20" => "Pointe Larue",
    "21" => "Port Glaud",
    "22" => "Saint Louis",
    "23" => "Takamaka",
    "24" => "Les Mamelles",
    "25" => "Roche Caiman",
    "26" => "Ile Perseverance I",
    "27" => "Ile Perseverance II"
  ]
];
