<?php
return [
  "country" => "Faroe Islands",
  "subdivisions" => [
  ]
];
