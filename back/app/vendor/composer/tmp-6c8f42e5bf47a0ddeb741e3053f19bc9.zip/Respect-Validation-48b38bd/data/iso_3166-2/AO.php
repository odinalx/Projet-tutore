<?php
return [
  "country" => "Angola",
  "subdivisions" => [
    "BGO" => "Bengo",
    "BGU" => "Benguela",
    "BIE" => "Bié",
    "CAB" => "Cabinda",
    "CCU" => "Cuando Cubango",
    "CNN" => "Cunene",
    "CNO" => "Cuanza-Norte",
    "CUS" => "Cuanza-Sul",
    "HUA" => "Huambo",
    "HUI" => "Huíla",
    "LNO" => "Lunda-Norte",
    "LSU" => "Lunda-Sul",
    "LUA" => "Luanda",
    "MAL" => "Malange",
    "MOX" => "Moxico",
    "NAM" => "Namibe",
    "UIG" => "Uíge",
    "ZAI" => "Zaire"
  ]
];
