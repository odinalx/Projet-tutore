<?php
return [
  "country" => "Armenia",
  "subdivisions" => [
    "AG" => "Aragac̣otn",
    "AR" => "Ararat",
    "AV" => "Armavir",
    "ER" => "Erevan",
    "GR" => "Geġark'unik'",
    "KT" => "Kotayk'",
    "LO" => "Loṙi",
    "SH" => "Širak",
    "SU" => "Syunik'",
    "TV" => "Tavuš",
    "VD" => "Vayoć Jor"
  ]
];
