<?php
return [
  "country" => "Israel",
  "subdivisions" => [
    "D" => "Al Janūbī",
    "HA" => "H̱efa",
    "JM" => "Al Quds",
    "M" => "Al Awsaţ",
    "TA" => "Tall Abīb",
    "Z" => "Ash Shamālī"
  ]
];
