<?php
return [
  "country" => "British Indian Ocean Territory",
  "subdivisions" => [
  ]
];
