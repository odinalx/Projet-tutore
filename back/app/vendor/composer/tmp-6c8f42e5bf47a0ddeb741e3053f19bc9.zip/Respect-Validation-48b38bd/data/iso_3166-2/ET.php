<?php
return [
  "country" => "Ethiopia",
  "subdivisions" => [
    "AA" => "Addis Ababa",
    "AF" => "Afar",
    "AM" => "Amara",
    "BE" => "Benshangul-Gumaz",
    "DD" => "Dire Dawa",
    "GA" => "Gambela Peoples",
    "HA" => "Harari People",
    "OR" => "Oromia",
    "SI" => "Sidama",
    "SN" => "Southern Nations, Nationalities and Peoples",
    "SO" => "Somali",
    "SW" => "Southwest Ethiopia Peoples",
    "TI" => "Tigrai"
  ]
];
