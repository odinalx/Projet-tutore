<?php
return [
  "country" => "Norway",
  "subdivisions" => [
    "03" => "Oslo",
    "11" => "Rogaland",
    "15" => "Møre og Romsdal",
    "18" => "Nordland",
    "21" => "Svalbard (Arctic Region)",
    "22" => "Jan Mayen (Arctic Region)",
    "30" => "Viken",
    "34" => "Innlandet",
    "38" => "Vestfold og Telemark",
    "42" => "Agder",
    "46" => "Vestland",
    "50" => "Trööndelage",
    "54" => "Romssa ja Finnmárkku"
  ]
];
