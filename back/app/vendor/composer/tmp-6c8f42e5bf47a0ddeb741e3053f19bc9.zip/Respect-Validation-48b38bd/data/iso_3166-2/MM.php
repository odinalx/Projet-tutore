<?php
return [
  "country" => "Myanmar",
  "subdivisions" => [
    "01" => "Sagaing",
    "02" => "Bago",
    "03" => "Magway",
    "04" => "Mandalay",
    "05" => "Tanintharyi",
    "06" => "Yangon",
    "07" => "Ayeyarwady",
    "11" => "Kachin",
    "12" => "Kayah",
    "13" => "Kayin",
    "14" => "Chin",
    "15" => "Mon",
    "16" => "Rakhine",
    "17" => "Shan",
    "18" => "Nay Pyi Taw"
  ]
];
