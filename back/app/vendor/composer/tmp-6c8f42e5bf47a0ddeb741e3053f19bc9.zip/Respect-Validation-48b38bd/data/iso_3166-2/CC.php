<?php
return [
  "country" => "Cocos (Keeling) Islands",
  "subdivisions" => [
  ]
];
