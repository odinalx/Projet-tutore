<?php
return [
  "country" => "Burundi",
  "subdivisions" => [
    "BB" => "Bubanza",
    "BL" => "Bujumbura Rural",
    "BM" => "Bujumbura Mairie",
    "BR" => "Bururi",
    "CA" => "Cankuzo",
    "CI" => "Cibitoke",
    "GI" => "Gitega",
    "KI" => "Kirundo",
    "KR" => "Karuzi",
    "KY" => "Kayanza",
    "MA" => "Makamba",
    "MU" => "Muramvya",
    "MW" => "Mwaro",
    "MY" => "Muyinga",
    "NG" => "Ngozi",
    "RM" => "Rumonge",
    "RT" => "Rutana",
    "RY" => "Ruyigi"
  ]
];
