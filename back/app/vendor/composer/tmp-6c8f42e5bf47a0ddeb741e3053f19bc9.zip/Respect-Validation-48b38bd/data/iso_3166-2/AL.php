<?php
return [
  "country" => "Albania",
  "subdivisions" => [
    "01" => "Berat",
    "02" => "Durrës",
    "03" => "Elbasan",
    "04" => "Fier",
    "05" => "Gjirokastër",
    "06" => "Korçë",
    "07" => "Kukës",
    "08" => "Lezhë",
    "09" => "Dibër",
    "10" => "Shkodër",
    "11" => "Tiranë",
    "12" => "Vlorë"
  ]
];
