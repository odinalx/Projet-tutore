<?php
return [
  "country" => "Kazakhstan",
  "subdivisions" => [
    "10" => "Abajskaja oblast’",
    "11" => "Akmolinskaja oblast'",
    "15" => "Aktjubinskaja oblast'",
    "19" => "Almatinskaja oblast'",
    "23" => "Atyrauskaja oblast'",
    "27" => "Batys Qazaqstan oblysy",
    "31" => "Zhambyl oblysy",
    "33" => "Zhetisū oblysy",
    "35" => "Karagandinskaja oblast'",
    "39" => "Kostanajskaja oblast'",
    "43" => "Kyzylordinskaja oblast'",
    "47" => "Mangghystaū oblysy",
    "55" => "Pavlodar oblysy",
    "59" => "Severo-Kazahstanskaja oblast'",
    "61" => "Turkestankaya oblast'",
    "62" => "Ulytauskaja oblast’",
    "63" => "Shyghys Qazaqstan oblysy",
    "71" => "Astana",
    "75" => "Almaty",
    "79" => "Shymkent"
  ]
];
