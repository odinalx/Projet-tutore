<?php
return [
  "country" => "Haiti",
  "subdivisions" => [
    "AR" => "Artibonite",
    "CE" => "Centre",
    "GA" => "Grande’Anse",
    "ND" => "Nord",
    "NE" => "Nord-Est",
    "NI" => "Nippes",
    "NO" => "Nord-Ouest",
    "OU" => "Ouest",
    "SD" => "Sud",
    "SE" => "Sud-Est"
  ]
];
