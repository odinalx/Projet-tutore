<?php
return [
  "country" => "Cyprus",
  "subdivisions" => [
    "01" => "Lefkosia",
    "02" => "Lemesos",
    "03" => "Larnaka",
    "04" => "Ammochostos",
    "05" => "Baf",
    "06" => "Girne"
  ]
];
