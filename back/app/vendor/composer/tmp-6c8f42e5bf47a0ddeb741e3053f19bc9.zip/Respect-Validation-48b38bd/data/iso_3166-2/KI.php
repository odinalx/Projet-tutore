<?php
return [
  "country" => "Kiribati",
  "subdivisions" => [
    "G" => "Gilbert Islands",
    "L" => "Line Islands",
    "P" => "Phoenix Islands"
  ]
];
