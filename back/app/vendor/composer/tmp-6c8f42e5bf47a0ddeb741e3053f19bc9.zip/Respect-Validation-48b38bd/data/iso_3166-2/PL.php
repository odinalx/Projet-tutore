<?php
return [
  "country" => "Poland",
  "subdivisions" => [
    "02" => "Dolnośląskie",
    "04" => "Kujawsko-Pomorskie",
    "06" => "Lubelskie",
    "08" => "Lubuskie",
    "10" => "Łódzkie",
    "12" => "Małopolskie",
    "14" => "Mazowieckie",
    "16" => "Opolskie",
    "18" => "Podkarpackie",
    "20" => "Podlaskie",
    "22" => "Pomorskie",
    "24" => "Śląskie",
    "26" => "Świętokrzyskie",
    "28" => "Warmińsko-Mazurskie",
    "30" => "Wielkopolskie",
    "32" => "Zachodniopomorskie"
  ]
];
