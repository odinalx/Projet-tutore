<?php
return [
  "country" => "Northern Mariana Islands",
  "subdivisions" => [
  ]
];
