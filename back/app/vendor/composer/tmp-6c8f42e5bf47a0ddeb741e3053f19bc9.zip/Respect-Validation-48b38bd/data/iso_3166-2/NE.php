<?php
return [
  "country" => "Niger",
  "subdivisions" => [
    "1" => "Agadez",
    "2" => "Diffa",
    "3" => "Dosso",
    "4" => "Maradi",
    "5" => "Tahoua",
    "6" => "Tillabéri",
    "7" => "Zinder",
    "8" => "Niamey"
  ]
];
