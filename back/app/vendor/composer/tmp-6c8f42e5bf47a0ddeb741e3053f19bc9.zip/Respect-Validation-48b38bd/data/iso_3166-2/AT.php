<?php
return [
  "country" => "Austria",
  "subdivisions" => [
    "1" => "Burgenland",
    "2" => "Kärnten",
    "3" => "Niederösterreich",
    "4" => "Oberösterreich",
    "5" => "Salzburg",
    "6" => "Steiermark",
    "7" => "Tirol",
    "8" => "Vorarlberg",
    "9" => "Wien"
  ]
];
