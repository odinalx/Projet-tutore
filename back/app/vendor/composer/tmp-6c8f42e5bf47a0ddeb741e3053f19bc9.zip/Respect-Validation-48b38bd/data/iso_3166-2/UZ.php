<?php
return [
  "country" => "Uzbekistan",
  "subdivisions" => [
    "AN" => "Andijon",
    "BU" => "Buxoro",
    "FA" => "Farg‘ona",
    "JI" => "Jizzax",
    "NG" => "Namangan",
    "NW" => "Navoiy",
    "QA" => "Qashqadaryo",
    "QR" => "Qoraqalpog‘iston Respublikasi",
    "SA" => "Samarqand",
    "SI" => "Sirdaryo",
    "SU" => "Surxondaryo",
    "TK" => "Toshkent",
    "TO" => "Toshkent",
    "XO" => "Xorazm"
  ]
];
