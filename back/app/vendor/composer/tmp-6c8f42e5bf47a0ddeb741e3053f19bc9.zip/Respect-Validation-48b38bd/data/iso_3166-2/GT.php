<?php
return [
  "country" => "Guatemala",
  "subdivisions" => [
    "01" => "Guatemala",
    "02" => "El Progreso",
    "03" => "Sacatepéquez",
    "04" => "Chimaltenango",
    "05" => "Escuintla",
    "06" => "Santa Rosa",
    "07" => "Sololá",
    "08" => "Totonicapán",
    "09" => "Quetzaltenango",
    "10" => "Suchitepéquez",
    "11" => "Retalhuleu",
    "12" => "San Marcos",
    "13" => "Huehuetenango",
    "14" => "Quiché",
    "15" => "Baja Verapaz",
    "16" => "Alta Verapaz",
    "17" => "Petén",
    "18" => "Izabal",
    "19" => "Zacapa",
    "20" => "Chiquimula",
    "21" => "Jalapa",
    "22" => "Jutiapa"
  ]
];
