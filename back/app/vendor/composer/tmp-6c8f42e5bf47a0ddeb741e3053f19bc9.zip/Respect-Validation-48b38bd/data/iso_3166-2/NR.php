<?php
return [
  "country" => "Nauru",
  "subdivisions" => [
    "01" => "Aiwo",
    "02" => "Anabar",
    "03" => "Anetan",
    "04" => "Anibare",
    "05" => "Baitsi",
    "06" => "Boe",
    "07" => "Buada",
    "08" => "Denigomodu",
    "09" => "Ewa",
    "10" => "Ijuw",
    "11" => "Meneng",
    "12" => "Nibok",
    "13" => "Uaboe",
    "14" => "Yaren"
  ]
];
