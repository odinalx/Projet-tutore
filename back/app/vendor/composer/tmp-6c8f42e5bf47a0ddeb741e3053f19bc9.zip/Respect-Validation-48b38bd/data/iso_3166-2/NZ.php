<?php
return [
  "country" => "New Zealand",
  "subdivisions" => [
    "AUK" => "Auckland",
    "BOP" => "Bay of Plenty",
    "CAN" => "Canterbury",
    "CIT" => "Chatham Islands Territory",
    "GIS" => "Gisborne",
    "HKB" => "Hawke's Bay",
    "MBH" => "Marlborough",
    "MWT" => "Manawatū-Whanganui",
    "NSN" => "Nelson",
    "NTL" => "Northland",
    "OTA" => "Otago",
    "STL" => "Southland",
    "TAS" => "Tasman",
    "TKI" => "Taranaki",
    "WGN" => "Greater Wellington",
    "WKO" => "Waikato",
    "WTC" => "West Coast"
  ]
];
