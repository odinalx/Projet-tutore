<?php
return [
  "country" => "Suriname",
  "subdivisions" => [
    "BR" => "Brokopondo",
    "CM" => "Commewijne",
    "CR" => "Coronie",
    "MA" => "Marowijne",
    "NI" => "Nickerie",
    "PM" => "Paramaribo",
    "PR" => "Para",
    "SA" => "Saramacca",
    "SI" => "Sipaliwini",
    "WA" => "Wanica"
  ]
];
