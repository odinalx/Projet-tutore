<?php
return [
  "country" => "American Samoa",
  "subdivisions" => [
  ]
];
