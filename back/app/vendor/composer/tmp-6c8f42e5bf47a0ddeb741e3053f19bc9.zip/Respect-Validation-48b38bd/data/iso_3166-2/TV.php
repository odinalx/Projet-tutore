<?php
return [
  "country" => "Tuvalu",
  "subdivisions" => [
    "FUN" => "Funafuti",
    "NIT" => "Niutao",
    "NKF" => "Nukufetau",
    "NKL" => "Nukulaelae",
    "NMA" => "Nanumea",
    "NMG" => "Nanumaga",
    "NUI" => "Nui",
    "VAI" => "Vaitupu"
  ]
];
