<?php
return [
  "country" => "Jersey",
  "subdivisions" => [
  ]
];
