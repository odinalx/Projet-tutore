<?php
return [
  "country" => "Bolivia, Plurinational State of",
  "subdivisions" => [
    "B" => "El Beni",
    "C" => "Cochabamba",
    "H" => "Chuquisaca",
    "L" => "La Paz",
    "N" => "Pando",
    "O" => "Oruro",
    "P" => "Potosí",
    "S" => "Santa Cruz",
    "T" => "Tarija"
  ]
];
