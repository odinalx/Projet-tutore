<?php
return [
  "country" => "Eritrea",
  "subdivisions" => [
    "AN" => "Ansabā",
    "DK" => "Debubawi K’eyyĭḥ Baḥri",
    "DU" => "Al Janūbī",
    "GB" => "Gash-Barka",
    "MA" => "Al Awsaţ",
    "SK" => "Semienawi K’eyyĭḥ Baḥri"
  ]
];
