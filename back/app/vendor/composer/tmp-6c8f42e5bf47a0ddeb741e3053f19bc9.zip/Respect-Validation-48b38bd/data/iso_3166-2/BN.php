<?php
return [
  "country" => "Brunei Darussalam",
  "subdivisions" => [
    "BE" => "Belait",
    "BM" => "Brunei-Muara",
    "TE" => "Temburong",
    "TU" => "Tutong"
  ]
];
