<?php
return [
  "country" => "Honduras",
  "subdivisions" => [
    "AT" => "Atlántida",
    "CH" => "Choluteca",
    "CL" => "Colón",
    "CM" => "Comayagua",
    "CP" => "Copán",
    "CR" => "Cortés",
    "EP" => "El Paraíso",
    "FM" => "Francisco Morazán",
    "GD" => "Gracias a Dios",
    "IB" => "Islas de la Bahía",
    "IN" => "Intibucá",
    "LE" => "Lempira",
    "LP" => "La Paz",
    "OC" => "Ocotepeque",
    "OL" => "Olancho",
    "SB" => "Santa Bárbara",
    "VA" => "Valle",
    "YO" => "Yoro"
  ]
];
