<?php
return [
  "country" => "Mozambique",
  "subdivisions" => [
    "A" => "Niassa",
    "B" => "Manica",
    "G" => "Gaza",
    "I" => "Inhambane",
    "L" => "Maputo",
    "MPM" => "Maputo",
    "N" => "Nampula",
    "P" => "Cabo Delgado",
    "Q" => "Zambézia",
    "S" => "Sofala",
    "T" => "Tete"
  ]
];
