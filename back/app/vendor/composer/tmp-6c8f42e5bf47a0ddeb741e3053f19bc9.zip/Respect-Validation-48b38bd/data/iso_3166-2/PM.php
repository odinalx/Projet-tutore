<?php
return [
  "country" => "Saint Pierre and Miquelon",
  "subdivisions" => [
  ]
];
