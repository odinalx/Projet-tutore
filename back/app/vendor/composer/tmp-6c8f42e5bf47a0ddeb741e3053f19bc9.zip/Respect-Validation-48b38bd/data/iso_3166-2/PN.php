<?php
return [
  "country" => "Pitcairn",
  "subdivisions" => [
  ]
];
