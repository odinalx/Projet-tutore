<?php
return [
  "country" => "Antigua and Barbuda",
  "subdivisions" => [
    "03" => "Saint George",
    "04" => "Saint John",
    "05" => "Saint Mary",
    "06" => "Saint Paul",
    "07" => "Saint Peter",
    "08" => "Saint Philip",
    "10" => "Barbuda",
    "11" => "Redonda"
  ]
];
