<?php
return [
  "country" => "Bhutan",
  "subdivisions" => [
    "11" => "Paro",
    "12" => "Chhukha",
    "13" => "Haa",
    "14" => "Samtse",
    "15" => "Thimphu",
    "21" => "Tsirang",
    "22" => "Dagana",
    "23" => "Punakha",
    "24" => "Wangdue Phodrang",
    "31" => "Sarpang",
    "32" => "Trongsa",
    "33" => "Bumthang",
    "34" => "Zhemgang",
    "41" => "Trashigang",
    "42" => "Monggar",
    "43" => "Pema Gatshel",
    "44" => "Lhuentse",
    "45" => "Samdrup Jongkhar",
    "GA" => "Gasa",
    "TY" => "Trashi Yangtse"
  ]
];
