<?php
return [
  "country" => "Samoa",
  "subdivisions" => [
    "AA" => "A'ana",
    "AL" => "Aiga-i-le-Tai",
    "AT" => "Atua",
    "FA" => "Fa'asaleleaga",
    "GE" => "Gaga'emauga",
    "GI" => "Gagaifomauga",
    "PA" => "Palauli",
    "SA" => "Satupa'itea",
    "TU" => "Tuamasaga",
    "VF" => "Va'a-o-Fonoti",
    "VS" => "Vaisigano"
  ]
];
