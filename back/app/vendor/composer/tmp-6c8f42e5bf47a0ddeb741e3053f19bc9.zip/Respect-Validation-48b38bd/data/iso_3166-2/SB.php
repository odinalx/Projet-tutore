<?php
return [
  "country" => "Solomon Islands",
  "subdivisions" => [
    "CE" => "Central",
    "CH" => "Choiseul",
    "CT" => "Capital Territory (Honiara)",
    "GU" => "Guadalcanal",
    "IS" => "Isabel",
    "MK" => "Makira-Ulawa",
    "ML" => "Malaita",
    "RB" => "Rennell and Bellona",
    "TE" => "Temotu",
    "WE" => "Western"
  ]
];
