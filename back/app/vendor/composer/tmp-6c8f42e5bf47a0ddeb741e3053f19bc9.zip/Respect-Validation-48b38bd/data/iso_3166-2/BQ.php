<?php
return [
  "country" => "Bonaire, Sint Eustatius and Saba",
  "subdivisions" => [
    "BO" => "Bonaire",
    "SA" => "Saba",
    "SE" => "Sint Eustatius"
  ]
];
