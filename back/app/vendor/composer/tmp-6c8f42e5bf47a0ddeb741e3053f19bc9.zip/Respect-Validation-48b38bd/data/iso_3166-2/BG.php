<?php
return [
  "country" => "Bulgaria",
  "subdivisions" => [
    "01" => "Blagoevgrad",
    "02" => "Burgas",
    "03" => "Varna",
    "04" => "Veliko Tarnovo",
    "05" => "Vidin",
    "06" => "Vratsa",
    "07" => "Gabrovo",
    "08" => "Dobrich",
    "09" => "Kardzhali",
    "10" => "Kyustendil",
    "11" => "Lovech",
    "12" => "Montana",
    "13" => "Pazardzhik",
    "14" => "Pernik",
    "15" => "Pleven",
    "16" => "Plovdiv",
    "17" => "Razgrad",
    "18" => "Ruse",
    "19" => "Silistra",
    "20" => "Sliven",
    "21" => "Smolyan",
    "22" => "Sofia (stolitsa)",
    "23" => "Sofia",
    "24" => "Stara Zagora",
    "25" => "Targovishte",
    "26" => "Haskovo",
    "27" => "Shumen",
    "28" => "Yambol"
  ]
];
