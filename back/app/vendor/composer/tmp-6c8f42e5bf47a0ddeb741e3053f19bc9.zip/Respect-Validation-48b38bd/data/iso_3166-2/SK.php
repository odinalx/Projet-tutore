<?php
return [
  "country" => "Slovakia",
  "subdivisions" => [
    "BC" => "Banskobystrický kraj",
    "BL" => "Bratislavský kraj",
    "KI" => "Košický kraj",
    "NI" => "Nitriansky kraj",
    "PV" => "Prešovský kraj",
    "TA" => "Trnavský kraj",
    "TC" => "Trenčiansky kraj",
    "ZI" => "Žilinský kraj"
  ]
];
