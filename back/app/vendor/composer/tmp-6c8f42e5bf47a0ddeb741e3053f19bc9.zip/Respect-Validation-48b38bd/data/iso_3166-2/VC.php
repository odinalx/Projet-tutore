<?php
return [
  "country" => "Saint Vincent and the Grenadines",
  "subdivisions" => [
    "01" => "Charlotte",
    "02" => "Saint Andrew",
    "03" => "Saint David",
    "04" => "Saint George",
    "05" => "Saint Patrick",
    "06" => "Grenadines"
  ]
];
