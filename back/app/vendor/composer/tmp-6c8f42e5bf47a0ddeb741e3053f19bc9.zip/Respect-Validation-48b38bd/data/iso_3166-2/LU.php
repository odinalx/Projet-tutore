<?php
return [
  "country" => "Luxembourg",
  "subdivisions" => [
    "CA" => "Capellen",
    "CL" => "Clervaux",
    "DI" => "Diekirch",
    "EC" => "Echternach",
    "ES" => "Esch-sur-Alzette",
    "GR" => "Grevenmacher",
    "LU" => "Luxembourg",
    "ME" => "Mersch",
    "RD" => "Redange",
    "RM" => "Remich",
    "VD" => "Vianden",
    "WI" => "Wiltz"
  ]
];
