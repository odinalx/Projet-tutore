<?php
return [
  "country" => "Saint Helena, Ascension and Tristan da Cunha",
  "subdivisions" => [
    "AC" => "Ascension",
    "HL" => "Saint Helena",
    "TA" => "Tristan da Cunha"
  ]
];
