<?php
return [
  "country" => "Belgium",
  "subdivisions" => [
    "BRU" => "Bruxelles-Capitale, Région de",
    "VAN" => "Antwerpen",
    "VBR" => "Vlaams-Brabant",
    "VLG" => "Vlaams Gewest",
    "VLI" => "Limburg",
    "VOV" => "Oost-Vlaanderen",
    "VWV" => "West-Vlaanderen",
    "WAL" => "wallonne, Région",
    "WBR" => "Brabant wallon",
    "WHT" => "Hainaut",
    "WLG" => "Liège",
    "WLX" => "Luxembourg",
    "WNA" => "Namur"
  ]
];
