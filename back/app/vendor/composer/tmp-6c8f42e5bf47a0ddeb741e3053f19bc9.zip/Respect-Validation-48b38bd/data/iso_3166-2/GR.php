<?php
return [
  "country" => "Greece",
  "subdivisions" => [
    "69" => "Ágion Óros",
    "A" => "Anatolikí Makedonía kai Thráki",
    "B" => "Kentrikí Makedonía",
    "C" => "Dytikí Makedonía",
    "D" => "Ípeiros",
    "E" => "Thessalía",
    "F" => "Ionía Nísia",
    "G" => "Dytikí Elláda",
    "H" => "Stereá Elláda",
    "I" => "Attikí",
    "J" => "Pelopónnisos",
    "K" => "Vóreio Aigaío",
    "L" => "Nótio Aigaío",
    "M" => "Kríti"
  ]
];
