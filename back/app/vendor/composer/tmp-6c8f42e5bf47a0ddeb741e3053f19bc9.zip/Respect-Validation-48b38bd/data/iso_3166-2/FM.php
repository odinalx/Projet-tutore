<?php
return [
  "country" => "Micronesia, Federated States of",
  "subdivisions" => [
    "KSA" => "Kosrae",
    "PNI" => "Pohnpei",
    "TRK" => "Chuuk",
    "YAP" => "Yap"
  ]
];
