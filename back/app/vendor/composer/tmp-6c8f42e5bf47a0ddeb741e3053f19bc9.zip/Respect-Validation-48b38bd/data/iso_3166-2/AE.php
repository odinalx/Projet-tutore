<?php
return [
  "country" => "United Arab Emirates",
  "subdivisions" => [
    "AJ" => "‘Ajmān",
    "AZ" => "Abū Z̧aby",
    "DU" => "Dubayy",
    "FU" => "Al Fujayrah",
    "RK" => "Ra’s al Khaymah",
    "SH" => "Ash Shāriqah",
    "UQ" => "Umm al Qaywayn"
  ]
];
