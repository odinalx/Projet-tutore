<?php
return [
  "country" => "Mauritania",
  "subdivisions" => [
    "01" => "Hodh ech Chargui",
    "02" => "Hodh el Gharbi",
    "03" => "Assaba",
    "04" => "Gorgol",
    "05" => "Brakna",
    "06" => "Trarza",
    "07" => "Adrar",
    "08" => "Dakhlet Nouâdhibou",
    "09" => "Tagant",
    "10" => "Guidimaka",
    "11" => "Tiris Zemmour",
    "12" => "Inchiri",
    "13" => "Nouakchott Ouest",
    "14" => "Nouakchott Nord",
    "15" => "Nouakchott Sud"
  ]
];
