<?php
return [
  "country" => "Greenland",
  "subdivisions" => [
    "AV" => "Avannaata Kommunia",
    "KU" => "Kommune Kujalleq",
    "QE" => "Qeqqata Kommunia",
    "QT" => "Kommune Qeqertalik",
    "SM" => "Kommuneqarfik Sermersooq"
  ]
];
