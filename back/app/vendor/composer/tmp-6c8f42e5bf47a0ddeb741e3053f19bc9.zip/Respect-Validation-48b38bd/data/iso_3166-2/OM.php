<?php
return [
  "country" => "Oman",
  "subdivisions" => [
    "BJ" => "Janūb al Bāţinah",
    "BS" => "Shamāl al Bāţinah",
    "BU" => "Al Buraymī",
    "DA" => "Ad Dākhilīyah",
    "MA" => "Masqaţ",
    "MU" => "Musandam",
    "SJ" => "Janūb ash Sharqīyah",
    "SS" => "Shamāl ash Sharqīyah",
    "WU" => "Al Wusţá",
    "ZA" => "Az̧ Z̧āhirah",
    "ZU" => "Z̧ufār"
  ]
];
