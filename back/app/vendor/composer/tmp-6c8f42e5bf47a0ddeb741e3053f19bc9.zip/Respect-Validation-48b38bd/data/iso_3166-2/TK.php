<?php
return [
  "country" => "Tokelau",
  "subdivisions" => [
  ]
];
