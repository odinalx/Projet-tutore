<?php
return [
  "country" => "Belize",
  "subdivisions" => [
    "BZ" => "Belize",
    "CY" => "Cayo",
    "CZL" => "Corozal",
    "OW" => "Orange Walk",
    "SC" => "Stann Creek",
    "TOL" => "Toledo"
  ]
];
