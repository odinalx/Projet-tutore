<?php
return [
  "country" => "Ecuador",
  "subdivisions" => [
    "A" => "Azuay",
    "B" => "Bolívar",
    "C" => "Carchi",
    "D" => "Orellana",
    "E" => "Esmeraldas",
    "F" => "Cañar",
    "G" => "Guayas",
    "H" => "Chimborazo",
    "I" => "Imbabura",
    "L" => "Loja",
    "M" => "Manabí",
    "N" => "Napo",
    "O" => "El Oro",
    "P" => "Pichincha",
    "R" => "Los Ríos",
    "S" => "Morona Santiago",
    "SD" => "Santo Domingo de los Tsáchilas",
    "SE" => "Santa Elena",
    "T" => "Tungurahua",
    "U" => "Sucumbíos",
    "W" => "Galápagos",
    "X" => "Cotopaxi",
    "Y" => "Pastaza",
    "Z" => "Zamora Chinchipe"
  ]
];
