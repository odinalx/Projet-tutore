<?php
return [
  "country" => "Fiji",
  "subdivisions" => [
    "01" => "Ba",
    "02" => "Bua",
    "03" => "Cakaudrove",
    "04" => "Kadavu",
    "05" => "Lau",
    "06" => "Lomaiviti",
    "07" => "Macuata",
    "08" => "Nadroga and Navosa",
    "09" => "Naitasiri",
    "10" => "Namosi",
    "11" => "Ra",
    "12" => "Rewa",
    "13" => "Serua",
    "14" => "Tailevu",
    "C" => "Central",
    "E" => "Eastern",
    "N" => "Northern",
    "R" => "Rotuma",
    "W" => "Western"
  ]
];
