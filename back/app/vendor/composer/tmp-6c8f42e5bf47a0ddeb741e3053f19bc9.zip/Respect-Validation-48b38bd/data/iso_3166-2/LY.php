<?php
return [
  "country" => "Libya",
  "subdivisions" => [
    "BA" => "Banghāzī",
    "BU" => "Al Buţnān",
    "DR" => "Darnah",
    "GT" => "Ghāt",
    "JA" => "Al Jabal al Akhḑar",
    "JG" => "Al Jabal al Gharbī",
    "JI" => "Al Jafārah",
    "JU" => "Al Jufrah",
    "KF" => "Al Kufrah",
    "MB" => "Al Marqab",
    "MI" => "Mişrātah",
    "MJ" => "Al Marj",
    "MQ" => "Murzuq",
    "NL" => "Nālūt",
    "NQ" => "An Nuqāţ al Khams",
    "SB" => "Sabhā",
    "SR" => "Surt",
    "TB" => "Ţarābulus",
    "WA" => "Al Wāḩāt",
    "WD" => "Wādī al Ḩayāt",
    "WS" => "Wādī ash Shāţi’",
    "ZA" => "Az Zāwiyah"
  ]
];
