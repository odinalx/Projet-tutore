<?php
return [
  "country" => "Jordan",
  "subdivisions" => [
    "AJ" => "‘Ajlūn",
    "AM" => "Al ‘A̅şimah",
    "AQ" => "Al ‘Aqabah",
    "AT" => "Aţ Ţafīlah",
    "AZ" => "Az Zarqā’",
    "BA" => "Al Balqā’",
    "IR" => "Irbid",
    "JA" => "Jarash",
    "KA" => "Al Karak",
    "MA" => "Al Mafraq",
    "MD" => "Mādabā",
    "MN" => "Ma‘ān"
  ]
];
