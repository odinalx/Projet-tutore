<?php
return [
  "country" => "New Caledonia",
  "subdivisions" => [
  ]
];
