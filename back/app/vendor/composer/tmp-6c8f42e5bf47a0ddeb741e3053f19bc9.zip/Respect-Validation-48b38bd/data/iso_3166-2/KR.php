<?php
return [
  "country" => "Korea, Republic of",
  "subdivisions" => [
    "11" => "Seoul-teukbyeolsi",
    "26" => "Busan-gwangyeoksi",
    "27" => "Daegu-gwangyeoksi",
    "28" => "Incheon-gwangyeoksi",
    "29" => "Gwangju-gwangyeoksi",
    "30" => "Daejeon-gwangyeoksi",
    "31" => "Ulsan-gwangyeoksi",
    "41" => "Gyeonggi-do",
    "42" => "Gangwon-teukbyeoljachido",
    "43" => "Chungcheongbuk-do",
    "44" => "Chungcheongnam-do",
    "45" => "Jeollabuk-do",
    "46" => "Jeollanam-do",
    "47" => "Gyeongsangbuk-do",
    "48" => "Gyeongsangnam-do",
    "49" => "Jeju-teukbyeoljachido",
    "50" => "Sejong"
  ]
];
