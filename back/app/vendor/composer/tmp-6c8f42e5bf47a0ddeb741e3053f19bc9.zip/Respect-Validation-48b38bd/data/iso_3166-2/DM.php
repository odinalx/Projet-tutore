<?php
return [
  "country" => "Dominica",
  "subdivisions" => [
    "02" => "Saint Andrew",
    "03" => "Saint David",
    "04" => "Saint George",
    "05" => "Saint John",
    "06" => "Saint Joseph",
    "07" => "Saint Luke",
    "08" => "Saint Mark",
    "09" => "Saint Patrick",
    "10" => "Saint Paul",
    "11" => "Saint Peter"
  ]
];
