<?php
return [
  "country" => "Liechtenstein",
  "subdivisions" => [
    "01" => "Balzers",
    "02" => "Eschen",
    "03" => "Gamprin",
    "04" => "Mauren",
    "05" => "Planken",
    "06" => "Ruggell",
    "07" => "Schaan",
    "08" => "Schellenberg",
    "09" => "Triesen",
    "10" => "Triesenberg",
    "11" => "Vaduz"
  ]
];
