<?php
return [
  "country" => "Mauritius",
  "subdivisions" => [
    "AG" => "Agalega Islands",
    "BL" => "Black River",
    "CC" => "Cargados Carajos Shoals",
    "FL" => "Flacq",
    "GP" => "Grand Port",
    "MO" => "Moka",
    "PA" => "Pamplemousses",
    "PL" => "Port Louis",
    "PW" => "Plaines Wilhems",
    "RO" => "Rodrigues Island",
    "RR" => "Rivière du Rempart",
    "SA" => "Savanne"
  ]
];
