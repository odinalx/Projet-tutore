<?php
return [
  "country" => "Bosnia and Herzegovina",
  "subdivisions" => [
    "BIH" => "Federacija Bosne i Hercegovine",
    "BRC" => "Brčko distrikt",
    "SRP" => "Republika Srpska"
  ]
];
