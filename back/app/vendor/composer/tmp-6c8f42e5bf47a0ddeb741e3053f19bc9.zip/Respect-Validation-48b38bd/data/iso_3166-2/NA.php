<?php
return [
  "country" => "Namibia",
  "subdivisions" => [
    "CA" => "Zambezi",
    "ER" => "Erongo",
    "HA" => "Hardap",
    "KA" => "//Karas",
    "KE" => "Kavango East",
    "KH" => "Khomas",
    "KU" => "Kunene",
    "KW" => "Kavango West",
    "OD" => "Otjozondjupa",
    "OH" => "Omaheke",
    "ON" => "Oshana",
    "OS" => "Omusati",
    "OT" => "Oshikoto",
    "OW" => "Ohangwena"
  ]
];
