<?php
return [
  "country" => "Costa Rica",
  "subdivisions" => [
    "A" => "Alajuela",
    "C" => "Cartago",
    "G" => "Guanacaste",
    "H" => "Heredia",
    "L" => "Limón",
    "P" => "Puntarenas",
    "SJ" => "San José"
  ]
];
