<?php
return [
  "country" => "Kuwait",
  "subdivisions" => [
    "AH" => "Al Aḩmadī",
    "FA" => "Al Farwānīyah",
    "HA" => "Ḩawallī",
    "JA" => "Al Jahrā’",
    "KU" => "Al ‘Āşimah",
    "MU" => "Mubārak al Kabīr"
  ]
];
