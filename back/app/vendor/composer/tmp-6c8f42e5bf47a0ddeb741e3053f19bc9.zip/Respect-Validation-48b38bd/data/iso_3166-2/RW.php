<?php
return [
  "country" => "Rwanda",
  "subdivisions" => [
    "01" => "City of Kigali",
    "02" => "Eastern",
    "03" => "Northern",
    "04" => "Western",
    "05" => "Southern"
  ]
];
