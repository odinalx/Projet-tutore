<?php
return [
  "country" => "Central African Republic",
  "subdivisions" => [
    "AC" => "Ouham",
    "BB" => "Bamingui-Bangoran",
    "BGF" => "Bangui",
    "BK" => "Basse-Kotto",
    "HK" => "Haute-Kotto",
    "HM" => "Haut-Mbomou",
    "HS" => "Haute-Sangha / Mambéré-Kadéï",
    "KB" => "Gribingui",
    "KG" => "Kémo-Gribingui",
    "LB" => "Lobaye",
    "MB" => "Mbomou",
    "MP" => "Ombella-Mpoko",
    "NM" => "Nana-Mambéré",
    "OP" => "Ouham-Pendé",
    "SE" => "Sangha",
    "UK" => "Ouaka",
    "VK" => "Vakaga"
  ]
];
