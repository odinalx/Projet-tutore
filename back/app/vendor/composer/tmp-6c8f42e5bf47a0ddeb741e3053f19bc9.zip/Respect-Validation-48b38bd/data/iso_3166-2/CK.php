<?php
return [
  "country" => "Cook Islands",
  "subdivisions" => [
  ]
];
