<?php
return [
  "country" => "Gambia",
  "subdivisions" => [
    "B" => "Banjul",
    "L" => "Lower River",
    "M" => "Central River",
    "N" => "North Bank",
    "U" => "Upper River",
    "W" => "Western"
  ]
];
