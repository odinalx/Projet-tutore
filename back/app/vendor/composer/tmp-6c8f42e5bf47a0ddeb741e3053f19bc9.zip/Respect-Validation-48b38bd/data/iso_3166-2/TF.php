<?php
return [
  "country" => "French Southern Territories",
  "subdivisions" => [
  ]
];
