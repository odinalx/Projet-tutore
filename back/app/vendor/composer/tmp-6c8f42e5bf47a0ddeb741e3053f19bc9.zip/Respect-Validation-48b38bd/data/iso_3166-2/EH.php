<?php
return [
  "country" => "Western Sahara",
  "subdivisions" => [
  ]
];
