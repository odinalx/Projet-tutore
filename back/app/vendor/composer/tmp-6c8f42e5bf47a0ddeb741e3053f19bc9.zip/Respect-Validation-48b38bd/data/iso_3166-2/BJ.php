<?php
return [
  "country" => "Benin",
  "subdivisions" => [
    "AK" => "Atacora",
    "AL" => "Alibori",
    "AQ" => "Atlantique",
    "BO" => "Borgou",
    "CO" => "Collines",
    "DO" => "Donga",
    "KO" => "Couffo",
    "LI" => "Littoral",
    "MO" => "Mono",
    "OU" => "Ouémé",
    "PL" => "Plateau",
    "ZO" => "Zou"
  ]
];
