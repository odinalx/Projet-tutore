<?php
return [
  "country" => "Cambodia",
  "subdivisions" => [
    "1" => "Banteay Mean Choăy",
    "10" => "Kracheh",
    "11" => "Mondol Kiri",
    "12" => "Phnom Penh",
    "13" => "Preah Vihear",
    "14" => "Prey Veaeng",
    "15" => "Pousaat",
    "16" => "Rotanak Kiri",
    "17" => "Siem Reab",
    "18" => "Preah Sihanouk",
    "19" => "Stoĕng Trêng",
    "2" => "Baat Dambang",
    "20" => "Svaay Rieng",
    "21" => "Taakaev",
    "22" => "Otdar Mean Chey",
    "23" => "Kaeb",
    "24" => "Pailin",
    "25" => "Tbong Khmum",
    "3" => "Kampong Chaam",
    "4" => "Kampong Chhnang",
    "5" => "Kampong Spueu",
    "6" => "Kampong Thum",
    "7" => "Kampot",
    "8" => "Kandaal",
    "9" => "Kaoh Kong"
  ]
];
