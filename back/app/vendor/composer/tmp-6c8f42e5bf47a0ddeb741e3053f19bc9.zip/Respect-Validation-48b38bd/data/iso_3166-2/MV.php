<?php
return [
  "country" => "Maldives",
  "subdivisions" => [
    "00" => "South Ari Atoll",
    "01" => "Addu City",
    "02" => "North Ari Atoll",
    "03" => "Faadhippolhu",
    "04" => "Felidhu Atoll",
    "05" => "Hahdhunmathi",
    "07" => "North Thiladhunmathi",
    "08" => "Kolhumadulu",
    "12" => "Mulaku Atoll",
    "13" => "North Maalhosmadulu",
    "14" => "North Nilandhe Atoll",
    "17" => "South Nilandhe Atoll",
    "20" => "South Maalhosmadulu",
    "23" => "South Thiladhunmathi",
    "24" => "North Miladhunmadulu",
    "25" => "South Miladhunmadulu",
    "26" => "Male Atoll",
    "27" => "North Huvadhu Atoll",
    "28" => "South Huvadhu Atoll",
    "29" => "Fuvammulah",
    "MLE" => "Male"
  ]
];
