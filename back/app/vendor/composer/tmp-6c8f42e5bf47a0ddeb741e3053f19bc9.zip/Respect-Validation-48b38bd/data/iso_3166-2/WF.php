<?php
return [
  "country" => "Wallis and Futuna",
  "subdivisions" => [
    "AL" => "Alo",
    "SG" => "Sigave",
    "UV" => "Uvea"
  ]
];
