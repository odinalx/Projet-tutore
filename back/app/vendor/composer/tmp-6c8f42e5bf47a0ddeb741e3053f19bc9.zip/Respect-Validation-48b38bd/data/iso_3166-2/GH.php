<?php
return [
  "country" => "Ghana",
  "subdivisions" => [
    "AA" => "Greater Accra",
    "AF" => "Ahafo",
    "AH" => "Ashanti",
    "BE" => "Bono East",
    "BO" => "Bono",
    "CP" => "Central",
    "EP" => "Eastern",
    "NE" => "North East",
    "NP" => "Northern",
    "OT" => "Oti",
    "SV" => "Savannah",
    "TV" => "Volta",
    "UE" => "Upper East",
    "UW" => "Upper West",
    "WN" => "Western North",
    "WP" => "Western"
  ]
];
