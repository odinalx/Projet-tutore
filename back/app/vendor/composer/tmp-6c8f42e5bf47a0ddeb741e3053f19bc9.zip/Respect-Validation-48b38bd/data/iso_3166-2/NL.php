<?php
return [
  "country" => "Netherlands",
  "subdivisions" => [
    "AW" => "Aruba",
    "BQ1" => "Bonaire",
    "BQ2" => "Saba",
    "BQ3" => "Sint Eustatius",
    "CW" => "Curaçao",
    "DR" => "Drenthe",
    "FL" => "Flevoland",
    "FR" => "Fryslân",
    "GE" => "Gelderland",
    "GR" => "Groningen",
    "LI" => "Limburg",
    "NB" => "Noord-Brabant",
    "NH" => "Noord-Holland",
    "OV" => "Overijssel",
    "SX" => "Sint Maarten",
    "UT" => "Utrecht",
    "ZE" => "Zeeland",
    "ZH" => "Zuid-Holland"
  ]
];
