<?php
return [
  "country" => "Sierra Leone",
  "subdivisions" => [
    "E" => "Eastern",
    "N" => "Northern",
    "NW" => "North Western",
    "S" => "Southern",
    "W" => "Western Area (Freetown)"
  ]
];
