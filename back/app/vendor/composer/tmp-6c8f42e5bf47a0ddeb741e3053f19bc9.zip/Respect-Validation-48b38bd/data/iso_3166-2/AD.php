<?php
return [
  "country" => "Andorra",
  "subdivisions" => [
    "02" => "Canillo",
    "03" => "Encamp",
    "04" => "La Massana",
    "05" => "Ordino",
    "06" => "Sant Julià de Lòria",
    "07" => "Andorra la Vella",
    "08" => "Escaldes-Engordany"
  ]
];
