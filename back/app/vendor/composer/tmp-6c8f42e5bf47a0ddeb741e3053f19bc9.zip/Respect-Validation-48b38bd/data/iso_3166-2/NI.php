<?php
return [
  "country" => "Nicaragua",
  "subdivisions" => [
    "AN" => "Costa Caribe Norte",
    "AS" => "Costa Caribe Sur",
    "BO" => "Boaco",
    "CA" => "Carazo",
    "CI" => "Chinandega",
    "CO" => "Chontales",
    "ES" => "Estelí",
    "GR" => "Granada",
    "JI" => "Jinotega",
    "LE" => "León",
    "MD" => "Madriz",
    "MN" => "Managua",
    "MS" => "Masaya",
    "MT" => "Matagalpa",
    "NS" => "Nueva Segovia",
    "RI" => "Rivas",
    "SJ" => "Río San Juan"
  ]
];
