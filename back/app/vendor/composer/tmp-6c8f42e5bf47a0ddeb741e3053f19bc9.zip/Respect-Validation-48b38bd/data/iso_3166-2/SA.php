<?php
return [
  "country" => "Saudi Arabia",
  "subdivisions" => [
    "01" => "Ar Riyāḑ",
    "02" => "Makkah al Mukarramah",
    "03" => "Al Madīnah al Munawwarah",
    "04" => "Ash Sharqīyah",
    "05" => "Al Qaşīm",
    "06" => "Ḩā'il",
    "07" => "Tabūk",
    "08" => "Al Ḩudūd ash Shamālīyah",
    "09" => "Jāzān",
    "10" => "Najrān",
    "11" => "Al Bāḩah",
    "12" => "Al Jawf",
    "14" => "'Asīr"
  ]
];
