<?php
return [
  "country" => "Mayotte",
  "subdivisions" => [
  ]
];
