<?php
return [
  "country" => "Lesotho",
  "subdivisions" => [
    "A" => "Maseru",
    "B" => "Botha-Bothe",
    "C" => "Leribe",
    "D" => "Berea",
    "E" => "Mafeteng",
    "F" => "Mohale's Hoek",
    "G" => "Quthing",
    "H" => "Qacha's Nek",
    "J" => "Mokhotlong",
    "K" => "Thaba-Tseka"
  ]
];
