<?php
return [
  "country" => "Côte d'Ivoire",
  "subdivisions" => [
    "AB" => "Abidjan",
    "BS" => "Bas-Sassandra",
    "CM" => "Comoé",
    "DN" => "Denguélé",
    "GD" => "Gôh-Djiboua",
    "LC" => "Lacs",
    "LG" => "Lagunes",
    "MG" => "Montagnes",
    "SM" => "Sassandra-Marahoué",
    "SV" => "Savanes",
    "VB" => "Vallée du Bandama",
    "WR" => "Woroba",
    "YM" => "Yamoussoukro",
    "ZZ" => "Zanzan"
  ]
];
