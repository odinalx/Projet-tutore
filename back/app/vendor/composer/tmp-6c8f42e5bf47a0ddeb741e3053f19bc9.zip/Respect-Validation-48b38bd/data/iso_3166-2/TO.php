<?php
return [
  "country" => "Tonga",
  "subdivisions" => [
    "01" => "'Eua",
    "02" => "Ha'apai",
    "03" => "Niuas",
    "04" => "Tongatapu",
    "05" => "Vava'u"
  ]
];
