<?php
return [
  "country" => "Svalbard and Jan Mayen",
  "subdivisions" => [
  ]
];
