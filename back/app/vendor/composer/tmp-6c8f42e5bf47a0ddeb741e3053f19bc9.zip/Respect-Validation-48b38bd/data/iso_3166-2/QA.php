<?php
return [
  "country" => "Qatar",
  "subdivisions" => [
    "DA" => "Ad Dawḩah",
    "KH" => "Al Khawr wa adh Dhakhīrah",
    "MS" => "Ash Shamāl",
    "RA" => "Ar Rayyān",
    "SH" => "Ash Shīḩānīyah",
    "US" => "Umm Şalāl",
    "WA" => "Al Wakrah",
    "ZA" => "Az̧ Z̧a‘āyin"
  ]
];
