<?php
return [
  "country" => "Germany",
  "subdivisions" => [
    "BB" => "Brandenburg",
    "BE" => "Berlin",
    "BW" => "Baden-Württemberg",
    "BY" => "Bayern",
    "HB" => "Bremen",
    "HE" => "Hessen",
    "HH" => "Hamburg",
    "MV" => "Mecklenburg-Vorpommern",
    "NI" => "Niedersachsen",
    "NW" => "Nordrhein-Westfalen",
    "RP" => "Rheinland-Pfalz",
    "SH" => "Schleswig-Holstein",
    "SL" => "Saarland",
    "SN" => "Sachsen",
    "ST" => "Sachsen-Anhalt",
    "TH" => "Thüringen"
  ]
];
