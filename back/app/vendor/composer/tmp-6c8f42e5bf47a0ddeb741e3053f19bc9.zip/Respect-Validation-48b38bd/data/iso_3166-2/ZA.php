<?php
return [
  "country" => "South Africa",
  "subdivisions" => [
    "EC" => "Eastern Cape",
    "FS" => "Free State",
    "GP" => "Gauteng",
    "KZN" => "Kwazulu-Natal",
    "LP" => "Limpopo",
    "MP" => "Mpumalanga",
    "NC" => "Northern Cape",
    "NW" => "North-West",
    "WC" => "Western Cape"
  ]
];
