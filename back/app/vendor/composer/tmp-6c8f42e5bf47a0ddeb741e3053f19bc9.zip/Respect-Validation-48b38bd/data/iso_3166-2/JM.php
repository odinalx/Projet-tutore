<?php
return [
  "country" => "Jamaica",
  "subdivisions" => [
    "01" => "Kingston",
    "02" => "Saint Andrew",
    "03" => "Saint Thomas",
    "04" => "Portland",
    "05" => "Saint Mary",
    "06" => "Saint Ann",
    "07" => "Trelawny",
    "08" => "Saint James",
    "09" => "Hanover",
    "10" => "Westmoreland",
    "11" => "Saint Elizabeth",
    "12" => "Manchester",
    "13" => "Clarendon",
    "14" => "Saint Catherine"
  ]
];
