<?php
return [
  "country" => "Singapore",
  "subdivisions" => [
    "01" => "Central Singapore",
    "02" => "North East",
    "03" => "North West",
    "04" => "South East",
    "05" => "South West"
  ]
];
