<?php
return [
  "country" => "Heard Island and McDonald Islands",
  "subdivisions" => [
  ]
];
