<?php
return [
  "country" => "El Salvador",
  "subdivisions" => [
    "AH" => "Ahuachapán",
    "CA" => "Cabañas",
    "CH" => "Chalatenango",
    "CU" => "Cuscatlán",
    "LI" => "La Libertad",
    "MO" => "Morazán",
    "PA" => "La Paz",
    "SA" => "Santa Ana",
    "SM" => "San Miguel",
    "SO" => "Sonsonate",
    "SS" => "San Salvador",
    "SV" => "San Vicente",
    "UN" => "La Unión",
    "US" => "Usulután"
  ]
];
