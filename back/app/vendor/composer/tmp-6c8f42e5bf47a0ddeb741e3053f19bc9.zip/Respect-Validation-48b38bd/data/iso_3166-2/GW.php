<?php
return [
  "country" => "Guinea-Bissau",
  "subdivisions" => [
    "BA" => "Bafatá",
    "BL" => "Bolama / Bijagós",
    "BM" => "Biombo",
    "BS" => "Bissau",
    "CA" => "Cacheu",
    "GA" => "Gabú",
    "L" => "Leste",
    "N" => "Norte",
    "OI" => "Oio",
    "QU" => "Quinara",
    "S" => "Sul",
    "TO" => "Tombali"
  ]
];
