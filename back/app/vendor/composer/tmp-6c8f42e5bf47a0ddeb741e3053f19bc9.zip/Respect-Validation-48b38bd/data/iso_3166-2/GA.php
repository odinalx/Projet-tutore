<?php
return [
  "country" => "Gabon",
  "subdivisions" => [
    "1" => "Estuaire",
    "2" => "Haut-Ogooué",
    "3" => "Moyen-Ogooué",
    "4" => "Ngounié",
    "5" => "Nyanga",
    "6" => "Ogooué-Ivindo",
    "7" => "Ogooué-Lolo",
    "8" => "Ogooué-Maritime",
    "9" => "Woleu-Ntem"
  ]
];
