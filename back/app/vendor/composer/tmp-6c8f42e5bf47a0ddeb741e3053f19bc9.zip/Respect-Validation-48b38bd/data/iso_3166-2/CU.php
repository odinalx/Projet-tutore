<?php
return [
  "country" => "Cuba",
  "subdivisions" => [
    "01" => "Pinar del Río",
    "03" => "La Habana",
    "04" => "Matanzas",
    "05" => "Villa Clara",
    "06" => "Cienfuegos",
    "07" => "Sancti Spíritus",
    "08" => "Ciego de Ávila",
    "09" => "Camagüey",
    "10" => "Las Tunas",
    "11" => "Holguín",
    "12" => "Granma",
    "13" => "Santiago de Cuba",
    "14" => "Guantánamo",
    "15" => "Artemisa",
    "16" => "Mayabeque",
    "99" => "Isla de la Juventud"
  ]
];
