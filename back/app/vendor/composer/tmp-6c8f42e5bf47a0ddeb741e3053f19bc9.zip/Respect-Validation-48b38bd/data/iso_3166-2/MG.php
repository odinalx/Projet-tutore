<?php
return [
  "country" => "Madagascar",
  "subdivisions" => [
    "A" => "Toamasina",
    "D" => "Antsiranana",
    "F" => "Fianarantsoa",
    "M" => "Mahajanga",
    "T" => "Antananarivo",
    "U" => "Toliara"
  ]
];
