<?php
return [
  "country" => "Bahrain",
  "subdivisions" => [
    "13" => "Al ‘Āşimah",
    "14" => "Al Janūbīyah",
    "15" => "Al Muḩarraq",
    "17" => "Ash Shamālīyah"
  ]
];
