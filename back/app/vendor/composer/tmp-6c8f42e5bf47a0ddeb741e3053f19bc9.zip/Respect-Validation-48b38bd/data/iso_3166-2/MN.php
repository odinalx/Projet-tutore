<?php
return [
  "country" => "Mongolia",
  "subdivisions" => [
    "035" => "Orhon",
    "037" => "Darhan uul",
    "039" => "Hentiy",
    "041" => "Hövsgöl",
    "043" => "Hovd",
    "046" => "Uvs",
    "047" => "Töv",
    "049" => "Selenge",
    "051" => "Sühbaatar",
    "053" => "Ömnögovĭ",
    "055" => "Övörhangay",
    "057" => "Dzavhan",
    "059" => "Dundgovĭ",
    "061" => "Dornod",
    "063" => "Dornogovĭ",
    "064" => "Govĭ-Sümber",
    "065" => "Govĭ-Altay",
    "067" => "Bulgan",
    "069" => "Bayanhongor",
    "071" => "Bayan-Ölgiy",
    "073" => "Arhangay",
    "1" => "Ulaanbaatar"
  ]
];
