<?php
return [
  "country" => "Timor-Leste",
  "subdivisions" => [
    "AL" => "Aileu",
    "AN" => "Ainaro",
    "BA" => "Baucau",
    "BO" => "Bobonaro",
    "CO" => "Cova Lima",
    "DI" => "Díli",
    "ER" => "Ermera",
    "LA" => "Lautein",
    "LI" => "Likisá",
    "MF" => "Manufahi",
    "MT" => "Manatuto",
    "OE" => "Oekusi-Ambenu",
    "VI" => "Vikeke"
  ]
];
