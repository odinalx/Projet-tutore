<?php
return [
  "country" => "Belarus",
  "subdivisions" => [
    "BR" => "Bresckaja voblasć",
    "HM" => "Gorod Minsk",
    "HO" => "Gomel'skaja oblast'",
    "HR" => "Grodnenskaja oblast'",
    "MA" => "Mahilioŭskaja voblasć",
    "MI" => "Minskaja oblast'",
    "VI" => "Viciebskaja voblasć"
  ]
];
