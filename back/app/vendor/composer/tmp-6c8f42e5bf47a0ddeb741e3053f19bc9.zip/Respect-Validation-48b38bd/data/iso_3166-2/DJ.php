<?php
return [
  "country" => "Djibouti",
  "subdivisions" => [
    "AR" => "Arta",
    "AS" => "Ali Sabieh",
    "DI" => "Dikhil",
    "DJ" => "Djibouti",
    "OB" => "Obock",
    "TA" => "Tadjourah"
  ]
];
