<?php
return [
  "country" => "Peru",
  "subdivisions" => [
    "AMA" => "Amarumayu",
    "ANC" => "Ancash",
    "APU" => "Apurimaq",
    "ARE" => "Arequipa",
    "AYA" => "Ayacucho",
    "CAJ" => "Cajamarca",
    "CAL" => "El Callao",
    "CUS" => "Cusco",
    "HUC" => "Huánuco",
    "HUV" => "Huancavelica",
    "ICA" => "Ica",
    "JUN" => "Hunin",
    "LAL" => "La Libertad",
    "LAM" => "Lambayeque",
    "LIM" => "Lima",
    "LMA" => "Lima hatun llaqta",
    "LOR" => "Loreto",
    "MDD" => "Madre de Dios",
    "MOQ" => "Moquegua",
    "PAS" => "Pasco",
    "PIU" => "Piura",
    "PUN" => "Puno",
    "SAM" => "San Martin",
    "TAC" => "Tacna",
    "TUM" => "Tumbes",
    "UCA" => "Ucayali"
  ]
];
